/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 *  com.mojang.brigadier.tree.CommandNode
 *  org.bukkit.plugin.Plugin
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.BrigadierProvider;
import com.massivecraft.factions.cmd.FCommand;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.tree.CommandNode;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import moss.factions.shade.me.lucko.commodore.Commodore;
import moss.factions.shade.me.lucko.commodore.CommodoreProvider;
import org.bukkit.plugin.Plugin;

public class BrigadierManager {
    public final Commodore commodore;
    public final LiteralArgumentBuilder<Object> brigadier;
    public final Set<String> aliases = new HashSet<String>();

    public BrigadierManager() {
        Object v;
        Map map = FactionsPlugin.getInstance().getDescription().getCommands();
        String string = (String)map.keySet().stream().findFirst().get();
        Map map2 = (Map)map.get(string);
        if (map2.containsKey("aliases") && (v = map2.get("aliases")) instanceof Collection) {
            this.aliases.addAll((Collection)v);
        }
        this.brigadier = LiteralArgumentBuilder.literal((String)string);
        this.commodore = CommodoreProvider.getCommodore((Plugin)FactionsPlugin.getInstance());
    }

    public void build() {
        this.commodore.register(this.brigadier.build());
        for (String string : this.aliases) {
            LiteralArgumentBuilder literalArgumentBuilder = LiteralArgumentBuilder.literal((String)string);
            for (CommandNode commandNode : this.brigadier.getArguments()) {
                literalArgumentBuilder.then(commandNode);
            }
            this.commodore.register(literalArgumentBuilder.build());
        }
    }

    public void addSubCommand(FCommand fCommand) {
        this.addSubCommand(fCommand, null);
    }

    public void addSubCommand(FCommand fCommand, ArgumentBuilder<Object, ?> argumentBuilder) {
        if (argumentBuilder == null) {
            argumentBuilder = this.brigadier;
        }
        for (String string : fCommand.aliases) {
            Iterator<FCommand> iterator;
            RequiredArgumentBuilder requiredArgumentBuilder;
            LiteralArgumentBuilder literalArgumentBuilder = LiteralArgumentBuilder.literal((String)string);
            if (fCommand.requirements.getBrigadier() != null) {
                requiredArgumentBuilder = fCommand.requirements.getBrigadier();
                try {
                    iterator = requiredArgumentBuilder.getDeclaredConstructor(new Class[0]);
                    argumentBuilder.then(((BrigadierProvider)((Constructor)((Object)iterator)).newInstance(new Object[0])).get((ArgumentBuilder<Object, ?>)literalArgumentBuilder));
                } catch (Exception exception) {
                    FactionsPlugin.getInstance().getLogger().log(Level.SEVERE, "Failed to reflectively access brigadier", exception);
                }
                continue;
            }
            requiredArgumentBuilder = null;
            if (fCommand.subCommands.isEmpty()) {
                iterator = new ArrayList();
                for (String string2 : fCommand.requiredArgs) {
                    iterator.add((FCommand)RequiredArgumentBuilder.argument((String)string2, (ArgumentType)StringArgumentType.word()));
                }
                for (Map.Entry entry : fCommand.optionalArgs.entrySet()) {
                    RequiredArgumentBuilder requiredArgumentBuilder2 = ((String)entry.getKey()).equalsIgnoreCase((String)entry.getValue()) ? RequiredArgumentBuilder.argument((String)(":" + (String)entry.getKey()), (ArgumentType)StringArgumentType.word()) : RequiredArgumentBuilder.argument((String)((String)entry.getKey() + "|" + (String)entry.getValue()), (ArgumentType)StringArgumentType.word());
                    iterator.add((FCommand)requiredArgumentBuilder2);
                }
                for (int i = iterator.size() - 1; i >= 0; --i) {
                    requiredArgumentBuilder = requiredArgumentBuilder == null ? (RequiredArgumentBuilder)iterator.get(i) : (RequiredArgumentBuilder)((RequiredArgumentBuilder)iterator.get(i)).then((ArgumentBuilder)requiredArgumentBuilder);
                }
            } else {
                for (FCommand fCommand2 : fCommand.subCommands) {
                    this.addSubCommand(fCommand2, (ArgumentBuilder<Object, ?>)literalArgumentBuilder);
                }
            }
            if (requiredArgumentBuilder == null) {
                argumentBuilder.then((ArgumentBuilder)literalArgumentBuilder);
                continue;
            }
            argumentBuilder.then(literalArgumentBuilder.then(requiredArgumentBuilder));
        }
    }
}

