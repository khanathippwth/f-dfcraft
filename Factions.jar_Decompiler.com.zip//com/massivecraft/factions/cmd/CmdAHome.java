/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.event.Event
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.event.FPlayerTeleportEvent;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.event.Event;

public class CmdAHome
extends FCommand {
    public CmdAHome() {
        this.aliases.add("ahome");
        this.requiredArgs.add("player");
        this.requirements = new CommandRequirements.Builder(Permission.AHOME).noDisableOnLock().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        FPlayer fPlayer = commandContext.argAsBestFPlayerMatch(0);
        if (fPlayer == null) {
            commandContext.msg(TL.GENERIC_NOPLAYERMATCH, commandContext.argAsString(0));
            return;
        }
        if (fPlayer.isOnline()) {
            Faction faction = fPlayer.getFaction();
            if (faction.hasHome()) {
                Location location = faction.getHome();
                FPlayerTeleportEvent fPlayerTeleportEvent = new FPlayerTeleportEvent(fPlayer, location, FPlayerTeleportEvent.PlayerTeleportReason.AHOME);
                Bukkit.getServer().getPluginManager().callEvent((Event)fPlayerTeleportEvent);
                if (fPlayerTeleportEvent.isCancelled()) {
                    return;
                }
                FactionsPlugin.getInstance().teleport(fPlayer.getPlayer(), location).thenAccept(bl -> {
                    if (bl.booleanValue()) {
                        commandContext.msg(TL.COMMAND_AHOME_SUCCESS, fPlayer.getName());
                        fPlayer.msg(TL.COMMAND_AHOME_TARGET, new Object[0]);
                    }
                });
            } else {
                commandContext.msg(TL.COMMAND_AHOME_NOHOME, fPlayer.getName());
            }
        } else {
            commandContext.msg(TL.COMMAND_AHOME_OFFLINE, fPlayer.getName());
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_AHOME_DESCRIPTION;
    }
}

