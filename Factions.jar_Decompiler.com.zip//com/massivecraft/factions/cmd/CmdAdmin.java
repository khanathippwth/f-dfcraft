/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.event.Event
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.event.FPlayerJoinEvent;
import com.massivecraft.factions.event.FactionNewAdminEvent;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;

public class CmdAdmin
extends FCommand {
    public CmdAdmin() {
        this.aliases.add("admin");
        this.aliases.add("setadmin");
        this.aliases.add("leader");
        this.aliases.add("setleader");
        this.requiredArgs.add("player");
        this.requirements = new CommandRequirements.Builder(Permission.ADMIN).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        Object object;
        FPlayer fPlayer = commandContext.argAsBestFPlayerMatch(0);
        if (fPlayer == null) {
            return;
        }
        boolean bl = Permission.ADMIN_ANY.has(commandContext.sender, false);
        Faction faction = fPlayer.getFaction();
        if (faction != commandContext.faction && !bl) {
            commandContext.msg(TL.COMMAND_ADMIN_NOTMEMBER, fPlayer.describeTo(commandContext.fPlayer, true));
            return;
        }
        if (commandContext.fPlayer != null && commandContext.fPlayer.getRole() != Role.ADMIN && !bl) {
            commandContext.msg(TL.COMMAND_ADMIN_NOTADMIN, new Object[0]);
            return;
        }
        if (fPlayer == commandContext.fPlayer && !bl) {
            commandContext.msg(TL.COMMAND_ADMIN_TARGETSELF, new Object[0]);
            return;
        }
        if (fPlayer.getFaction() != faction) {
            object = new FPlayerJoinEvent(FPlayers.getInstance().getByPlayer(commandContext.player), faction, FPlayerJoinEvent.PlayerJoinReason.LEADER);
            Bukkit.getServer().getPluginManager().callEvent((Event)object);
            if (((FPlayerJoinEvent)((Object)object)).isCancelled()) {
                return;
            }
        }
        if (fPlayer == (object = faction.getFPlayerAdmin())) {
            faction.promoteNewLeader();
            commandContext.msg(TL.COMMAND_ADMIN_DEMOTES, fPlayer.describeTo(commandContext.fPlayer, true));
            fPlayer.msg(TL.COMMAND_ADMIN_DEMOTED, commandContext.player == null ? TL.GENERIC_SERVERADMIN.toString() : commandContext.fPlayer.describeTo(fPlayer, true));
            return;
        }
        Bukkit.getServer().getPluginManager().callEvent((Event)new FactionNewAdminEvent(fPlayer, faction));
        if (object != null) {
            object.setRole(Role.COLEADER);
        }
        fPlayer.setRole(Role.ADMIN);
        commandContext.msg(TL.COMMAND_ADMIN_PROMOTES, fPlayer.describeTo(commandContext.fPlayer, true));
        for (FPlayer fPlayer2 : FPlayers.getInstance().getOnlinePlayers()) {
            fPlayer2.msg(TL.COMMAND_ADMIN_PROMOTED, commandContext.player == null ? TL.GENERIC_SERVERADMIN.toString() : commandContext.fPlayer.describeTo(fPlayer2, true), fPlayer.describeTo(fPlayer2), faction.describeTo(fPlayer2));
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_ADMIN_DESCRIPTION;
    }
}

