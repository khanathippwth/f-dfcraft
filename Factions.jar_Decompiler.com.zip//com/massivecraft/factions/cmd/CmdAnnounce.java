/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 *  org.bukkit.ChatColor
 *  org.bukkit.entity.Player
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.cmd.BrigadierProvider;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import org.apache.commons.lang3.StringUtils;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class CmdAnnounce
extends FCommand {
    public CmdAnnounce() {
        this.aliases.add("ann");
        this.aliases.add("announce");
        this.requiredArgs.add("message");
        this.requirements = new CommandRequirements.Builder(Permission.ANNOUNCE).memberOnly().withRole(Role.MODERATOR).noErrorOnManyArgs().noDisableOnLock().brigadier(AnnounceBrigadier.class).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        String string = String.valueOf(ChatColor.GREEN) + commandContext.faction.getTag() + String.valueOf(ChatColor.YELLOW) + " [" + String.valueOf(ChatColor.GRAY) + commandContext.player.getName() + String.valueOf(ChatColor.YELLOW) + "] " + String.valueOf(ChatColor.RESET);
        String string2 = StringUtils.join(commandContext.args, " ");
        for (Player object : commandContext.faction.getOnlinePlayers()) {
            object.sendMessage(string + string2);
        }
        for (FPlayer fPlayer : commandContext.faction.getFPlayersWhereOnline(false)) {
            commandContext.faction.addAnnouncement(fPlayer, string + string2);
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_ANNOUNCE_DESCRIPTION;
    }

    protected static class AnnounceBrigadier
    implements BrigadierProvider {
        protected AnnounceBrigadier() {
        }

        @Override
        public ArgumentBuilder<Object, ?> get(ArgumentBuilder<Object, ?> argumentBuilder) {
            return argumentBuilder.then((ArgumentBuilder)RequiredArgumentBuilder.argument((String)"message", (ArgumentType)StringArgumentType.greedyString()));
        }
    }
}

