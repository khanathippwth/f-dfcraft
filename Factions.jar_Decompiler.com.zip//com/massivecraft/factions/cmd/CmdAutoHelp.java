/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.util.TL;
import java.util.ArrayList;

public class CmdAutoHelp
extends FCommand {
    public CmdAutoHelp() {
        this.aliases.add("?");
        this.aliases.add("h");
        this.aliases.add("help");
        this.setHelpShort("");
        this.optionalArgs.put("page", "1");
    }

    @Override
    public void perform(CommandContext commandContext) {
        if (commandContext.commandChain.isEmpty()) {
            return;
        }
        FCommand fCommand = (FCommand)commandContext.commandChain.getLast();
        ArrayList<String> arrayList = new ArrayList<String>(fCommand.helpLong);
        for (FCommand fCommand2 : fCommand.subCommands) {
            if (fCommand2.visibility != FCommand.CommandVisibility.VISIBLE) continue;
            arrayList.add(fCommand2.getUsageTemplate(commandContext, true));
        }
        commandContext.sendMessage(FactionsPlugin.getInstance().txt().getPage(arrayList, commandContext.argAsInt(0, 1), String.valueOf((Object)TL.COMMAND_AUTOHELP_HELPFOR) + (String)fCommand.aliases.getFirst() + "\""));
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_HELP_DESCRIPTION;
    }
}

