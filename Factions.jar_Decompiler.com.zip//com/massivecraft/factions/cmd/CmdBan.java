/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.event.FPlayerLeaveEvent;
import com.massivecraft.factions.perms.PermissibleActions;
import com.massivecraft.factions.struct.BanInfo;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import java.util.logging.Level;
import org.bukkit.Bukkit;

public class CmdBan
extends FCommand {
    public CmdBan() {
        this.aliases.add("ban");
        this.requiredArgs.add("target");
        this.requirements = new CommandRequirements.Builder(Permission.BAN).memberOnly().withAction(PermissibleActions.BAN).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        FPlayer fPlayer = commandContext.argAsFPlayer(0);
        if (fPlayer == null) {
            return;
        }
        if (commandContext.fPlayer == fPlayer) {
            commandContext.msg(TL.COMMAND_BAN_SELF, new Object[0]);
            return;
        }
        if (fPlayer.getFaction() == commandContext.faction && fPlayer.getRole().value >= commandContext.fPlayer.getRole().value) {
            commandContext.msg(TL.COMMAND_BAN_INSUFFICIENTRANK, fPlayer.getName());
            return;
        }
        for (BanInfo banInfo : commandContext.faction.getBannedPlayers()) {
            if (!banInfo.getBanned().equals(fPlayer.getId())) continue;
            commandContext.msg(TL.COMMAND_BAN_ALREADYBANNED, fPlayer.getName());
            return;
        }
        commandContext.faction.ban(fPlayer, commandContext.fPlayer);
        commandContext.faction.deinvite(fPlayer);
        if (fPlayer.getFaction() == commandContext.faction) {
            FPlayerLeaveEvent fPlayerLeaveEvent = new FPlayerLeaveEvent(fPlayer, commandContext.faction, FPlayerLeaveEvent.PlayerLeaveReason.BANNED);
            Bukkit.getServer().getPluginManager().callEvent(fPlayerLeaveEvent);
            if (fPlayerLeaveEvent.isCancelled()) {
                FactionsPlugin.getInstance().log(Level.WARNING, "Attempted to ban {0} but someone cancelled the kick event. This isn't good.", fPlayer.getName());
                return;
            }
            commandContext.faction.removeFPlayer(fPlayer);
            fPlayer.resetFactionData();
        }
        fPlayer.msg(TL.COMMAND_BAN_TARGET, commandContext.faction.getTag(fPlayer.getFaction()));
        commandContext.faction.msg(TL.COMMAND_BAN_BANNED, commandContext.fPlayer.getName(), fPlayer.getName());
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_BAN_DESCRIPTION;
    }
}

