/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.BanInfo;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import java.util.ArrayList;

public class CmdBanlist
extends FCommand {
    public CmdBanlist() {
        this.aliases.add("banlist");
        this.aliases.add("bans");
        this.aliases.add("banl");
        this.optionalArgs.put("faction", "faction");
        this.requirements = new CommandRequirements.Builder(Permission.BAN).playerOnly().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        Faction faction = commandContext.faction;
        if (!commandContext.args.isEmpty()) {
            faction = commandContext.argAsFaction(0);
        }
        if (faction == null) {
            commandContext.msg(TL.COMMAND_BANLIST_INVALID.format(commandContext.argAsString(0)), new Object[0]);
            return;
        }
        if (!faction.isNormal()) {
            commandContext.msg(TL.COMMAND_BANLIST_NOFACTION, new Object[0]);
            return;
        }
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add(TL.COMMAND_BANLIST_HEADER.format(faction.getBannedPlayers().size(), faction.getTag(commandContext.faction)));
        int n = 1;
        for (BanInfo object : faction.getBannedPlayers()) {
            FPlayer fPlayer = FPlayers.getInstance().getById(object.getBanned());
            FPlayer fPlayer2 = FPlayers.getInstance().getById(object.getBanner());
            String string = TL.sdf.format(object.getTime());
            arrayList.add(TL.COMMAND_BANLIST_ENTRY.format(n, fPlayer.getName(), fPlayer2.getName(), string));
            ++n;
        }
        for (String string : arrayList) {
            commandContext.fPlayer.sendMessage(string);
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_BANLIST_DESCRIPTION;
    }
}

