/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdBoom
extends FCommand {
    public CmdBoom() {
        this.aliases.add("noboom");
        this.aliases.add("explosions");
        this.aliases.add("toggleexplosions");
        this.optionalArgs.put("on/off", "flip");
        this.requirements = new CommandRequirements.Builder(Permission.NO_BOOM).memberOnly().withRole(Role.MODERATOR).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        if (!commandContext.faction.isPeaceful()) {
            commandContext.msg(TL.COMMAND_BOOM_PEACEFULONLY, new Object[0]);
            return;
        }
        if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostNoBoom(), TL.COMMAND_BOOM_TOTOGGLE, TL.COMMAND_BOOM_FORTOGGLE)) {
            return;
        }
        commandContext.faction.setPeacefulExplosionsEnabled(commandContext.argAsBool(0, !commandContext.faction.getPeacefulExplosionsEnabled()));
        String string = commandContext.faction.noExplosionsInTerritory() ? TL.GENERIC_DISABLED.toString() : TL.GENERIC_ENABLED.toString();
        commandContext.faction.msg(TL.COMMAND_BOOM_ENABLED, commandContext.fPlayer.describeTo(commandContext.faction), string);
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_BOOM_DESCRIPTION;
    }
}

