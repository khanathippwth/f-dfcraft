/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdBypass
extends FCommand {
    public CmdBypass() {
        this.aliases.add("bypass");
        this.optionalArgs.put("on/off", "flip");
        this.requirements = new CommandRequirements.Builder(Permission.BYPASS).playerOnly().noDisableOnLock().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        commandContext.fPlayer.setIsAdminBypassing(commandContext.argAsBool(0, !commandContext.fPlayer.isAdminBypassing()));
        if (commandContext.fPlayer.isAdminBypassing()) {
            commandContext.fPlayer.msg(TL.COMMAND_BYPASS_ENABLE, new Object[0]);
            FactionsPlugin.getInstance().log(commandContext.fPlayer.getName() + String.valueOf((Object)TL.COMMAND_BYPASS_ENABLELOG));
        } else {
            commandContext.fPlayer.msg(TL.COMMAND_BYPASS_DISABLE, new Object[0]);
            FactionsPlugin.getInstance().log(commandContext.fPlayer.getName() + String.valueOf((Object)TL.COMMAND_BYPASS_DISABLELOG));
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_BYPASS_DESCRIPTION;
    }
}

