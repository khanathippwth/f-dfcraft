/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.BrigadierProvider;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.ChatMode;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;

public class CmdChat
extends FCommand {
    public CmdChat() {
        this.aliases.add("c");
        this.aliases.add("chat");
        this.optionalArgs.put("mode", "next");
        this.requirements = new CommandRequirements.Builder(Permission.CHAT).memberOnly().noDisableOnLock().brigadier(ChatBrigadier.class).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        if (!FactionsPlugin.getInstance().conf().factions().chat().isFactionOnlyChat()) {
            commandContext.msg(TL.COMMAND_CHAT_DISABLED.toString(), new Object[0]);
            return;
        }
        String string = commandContext.argAsString(0);
        ChatMode chatMode = commandContext.fPlayer.getChatMode().getNext();
        if (string == null && chatMode == ChatMode.MOD && !commandContext.fPlayer.getRole().isAtLeast(Role.MODERATOR)) {
            chatMode = chatMode.getNext();
        }
        if (string != null) {
            if ((string = string.toLowerCase()).startsWith("m")) {
                chatMode = ChatMode.MOD;
                if (!commandContext.fPlayer.getRole().isAtLeast(Role.MODERATOR)) {
                    commandContext.msg(TL.COMMAND_CHAT_INSUFFICIENTRANK, new Object[0]);
                    return;
                }
            } else if (string.startsWith("p")) {
                chatMode = ChatMode.PUBLIC;
            } else if (string.startsWith("a")) {
                chatMode = ChatMode.ALLIANCE;
            } else if (string.startsWith("f")) {
                chatMode = ChatMode.FACTION;
            } else if (string.startsWith("t")) {
                chatMode = ChatMode.TRUCE;
            } else {
                commandContext.msg(TL.COMMAND_CHAT_INVALIDMODE, new Object[0]);
                return;
            }
        }
        commandContext.fPlayer.setChatMode(chatMode);
        if (commandContext.fPlayer.getChatMode() == ChatMode.MOD) {
            commandContext.msg(TL.COMMAND_CHAT_MODE_MOD, new Object[0]);
        } else if (commandContext.fPlayer.getChatMode() == ChatMode.PUBLIC) {
            commandContext.msg(TL.COMMAND_CHAT_MODE_PUBLIC, new Object[0]);
        } else if (commandContext.fPlayer.getChatMode() == ChatMode.ALLIANCE) {
            commandContext.msg(TL.COMMAND_CHAT_MODE_ALLIANCE, new Object[0]);
        } else if (commandContext.fPlayer.getChatMode() == ChatMode.TRUCE) {
            commandContext.msg(TL.COMMAND_CHAT_MODE_TRUCE, new Object[0]);
        } else {
            commandContext.msg(TL.COMMAND_CHAT_MODE_FACTION, new Object[0]);
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_CHAT_DESCRIPTION;
    }

    protected static class ChatBrigadier
    implements BrigadierProvider {
        protected ChatBrigadier() {
        }

        @Override
        public ArgumentBuilder<Object, ?> get(ArgumentBuilder<Object, ?> argumentBuilder) {
            return argumentBuilder.then((ArgumentBuilder)LiteralArgumentBuilder.literal((String)"public")).then((ArgumentBuilder)LiteralArgumentBuilder.literal((String)"mod")).then((ArgumentBuilder)LiteralArgumentBuilder.literal((String)"alliance")).then((ArgumentBuilder)LiteralArgumentBuilder.literal((String)"faction")).then((ArgumentBuilder)LiteralArgumentBuilder.literal((String)"truce"));
        }
    }
}

