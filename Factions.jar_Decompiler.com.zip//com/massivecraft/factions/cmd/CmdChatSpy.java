/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdChatSpy
extends FCommand {
    public CmdChatSpy() {
        this.aliases.add("chatspy");
        this.optionalArgs.put("on/off", "flip");
        this.requirements = new CommandRequirements.Builder(Permission.CHATSPY).playerOnly().noDisableOnLock().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        commandContext.fPlayer.setSpyingChat(commandContext.argAsBool(0, !commandContext.fPlayer.isSpyingChat()));
        if (commandContext.fPlayer.isSpyingChat()) {
            commandContext.fPlayer.msg(TL.COMMAND_CHATSPY_ENABLE, new Object[0]);
            FactionsPlugin.getInstance().log(commandContext.fPlayer.getName() + String.valueOf((Object)TL.COMMAND_CHATSPY_ENABLELOG));
        } else {
            commandContext.fPlayer.msg(TL.COMMAND_CHATSPY_DISABLE, new Object[0]);
            FactionsPlugin.getInstance().log(commandContext.fPlayer.getName() + String.valueOf((Object)TL.COMMAND_CHATSPY_DISABLELOG));
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_CHATSPY_DESCRIPTION;
    }
}

