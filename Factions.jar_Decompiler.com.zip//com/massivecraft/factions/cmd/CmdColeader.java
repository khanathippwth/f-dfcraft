/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import moss.factions.shade.net.kyori.adventure.text.Component;
import moss.factions.shade.net.kyori.adventure.text.ComponentBuilder;
import moss.factions.shade.net.kyori.adventure.text.TextComponent;
import moss.factions.shade.net.kyori.adventure.text.event.ClickEvent;
import moss.factions.shade.net.kyori.adventure.text.event.HoverEventSource;
import moss.factions.shade.net.kyori.adventure.text.format.NamedTextColor;
import moss.factions.shade.net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public class CmdColeader
extends FCommand {
    public CmdColeader() {
        this.aliases.add("coleader");
        this.aliases.add("setcoleader");
        this.aliases.add("cl");
        this.aliases.add("setcl");
        this.requiredArgs.add("player");
        this.requirements = new CommandRequirements.Builder(Permission.COLEADER).memberOnly().withRole(Role.ADMIN).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        FPlayer fPlayer = commandContext.argAsBestFPlayerMatch(0);
        if (fPlayer == null) {
            LegacyComponentSerializer legacyComponentSerializer = LegacyComponentSerializer.legacySection();
            Component component = legacyComponentSerializer.deserialize(TL.COMMAND_COLEADER_CANDIDATES.toString()).color(NamedTextColor.GOLD);
            for (FPlayer fPlayer2 : commandContext.faction.getFPlayersWhereRole(Role.MODERATOR)) {
                String string = fPlayer2.getName();
                component = component.append((ComponentBuilder<?, ?>)((TextComponent.Builder)((TextComponent.Builder)Component.text().color(NamedTextColor.WHITE)).content(string + " ").hoverEvent((HoverEventSource)legacyComponentSerializer.deserialize(String.valueOf((Object)TL.COMMAND_COLEADER_CLICKTOPROMOTE) + string))).clickEvent(ClickEvent.runCommand("/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " coleader " + string)));
            }
            FactionsPlugin.getInstance().getAdventure().player(commandContext.player).sendMessage(component);
            return;
        }
        boolean bl = Permission.COLEADER_ANY.has(commandContext.sender, false);
        Faction faction = fPlayer.getFaction();
        if (faction != commandContext.faction && !bl) {
            commandContext.msg(TL.COMMAND_COLEADER_NOTMEMBER, fPlayer.describeTo(commandContext.fPlayer, true));
            return;
        }
        if (commandContext.fPlayer != null && commandContext.fPlayer.getRole() != Role.ADMIN && !bl) {
            commandContext.msg(TL.COMMAND_COLEADER_NOTADMIN, new Object[0]);
            return;
        }
        if (fPlayer == commandContext.fPlayer && !bl) {
            commandContext.msg(TL.COMMAND_COLEADER_SELF, new Object[0]);
            return;
        }
        if (fPlayer.getRole() == Role.ADMIN) {
            commandContext.msg(TL.COMMAND_COLEADER_TARGETISADMIN, new Object[0]);
            return;
        }
        if (fPlayer.getRole() == Role.COLEADER) {
            fPlayer.setRole(Role.MODERATOR);
            faction.msg(TL.COMMAND_COLEADER_REVOKED, fPlayer.describeTo(faction, true));
            commandContext.msg(TL.COMMAND_COLEADER_REVOKES, fPlayer.describeTo(commandContext.fPlayer, true));
            return;
        }
        if (!FactionsPlugin.getInstance().conf().factions().other().isAllowMultipleColeaders() && !faction.getFPlayersWhereRole(Role.COLEADER).isEmpty()) {
            commandContext.msg(TL.COMMAND_COLEADER_ALREADY_COLEADER, new Object[0]);
            return;
        }
        fPlayer.setRole(Role.COLEADER);
        faction.msg(TL.COMMAND_COLEADER_PROMOTED, fPlayer.describeTo(faction, true));
        commandContext.msg(TL.COMMAND_COLEADER_PROMOTES, fPlayer.describeTo(commandContext.fPlayer, true));
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_COLEADER_DESCRIPTION;
    }
}

