/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import org.bukkit.Location;

public class CmdCoords
extends FCommand {
    public CmdCoords() {
        this.aliases.add("coords");
        this.aliases.add("coord");
        this.requirements = new CommandRequirements.Builder(Permission.COORDS).memberOnly().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        Location location = commandContext.player.getLocation();
        String string = TL.COMMAND_COORDS_MESSAGE.format(commandContext.player.getDisplayName(), location.getBlockX(), location.getBlockY(), location.getBlockZ(), location.getWorld().getName());
        for (FPlayer fPlayer : commandContext.faction.getFPlayers()) {
            fPlayer.sendMessage(string);
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_COORDS_DESCRIPTION;
    }
}

