/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.event.Event
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.Factions;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCmdRoot;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.event.FPlayerJoinEvent;
import com.massivecraft.factions.event.FactionAttemptCreateEvent;
import com.massivecraft.factions.event.FactionCreateEvent;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.MiscUtil;
import com.massivecraft.factions.util.TL;
import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;

public class CmdCreate
extends FCommand {
    public CmdCreate() {
        this.aliases.add("create");
        this.requiredArgs.add("faction tag");
        this.requirements = new CommandRequirements.Builder(Permission.CREATE).playerOnly().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        String string = commandContext.argAsString(0);
        if (commandContext.fPlayer.hasFaction()) {
            commandContext.msg(TL.COMMAND_CREATE_MUSTLEAVE, new Object[0]);
            return;
        }
        if (Factions.getInstance().isTagTaken(string)) {
            commandContext.msg(TL.COMMAND_CREATE_INUSE, new Object[0]);
            return;
        }
        ArrayList<String> arrayList = MiscUtil.validateTag(string);
        if (!arrayList.isEmpty()) {
            commandContext.sendMessage(arrayList);
            return;
        }
        if (!commandContext.canAffordCommand(FactionsPlugin.getInstance().conf().economy().getCostCreate(), TL.COMMAND_CREATE_TOCREATE.toString())) {
            return;
        }
        FactionAttemptCreateEvent factionAttemptCreateEvent = new FactionAttemptCreateEvent(commandContext.player, string);
        Bukkit.getServer().getPluginManager().callEvent((Event)factionAttemptCreateEvent);
        if (factionAttemptCreateEvent.isCancelled()) {
            return;
        }
        if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostCreate(), TL.COMMAND_CREATE_TOCREATE, TL.COMMAND_CREATE_FORCREATE)) {
            return;
        }
        Faction faction = Factions.getInstance().createFaction();
        if (faction == null) {
            commandContext.msg(TL.COMMAND_CREATE_ERROR, new Object[0]);
            return;
        }
        faction.setTag(string);
        FPlayerJoinEvent fPlayerJoinEvent = new FPlayerJoinEvent(FPlayers.getInstance().getByPlayer(commandContext.player), faction, FPlayerJoinEvent.PlayerJoinReason.CREATE);
        Bukkit.getServer().getPluginManager().callEvent((Event)fPlayerJoinEvent);
        commandContext.fPlayer.setRole(Role.ADMIN);
        commandContext.fPlayer.setFaction(faction);
        FactionCreateEvent factionCreateEvent = new FactionCreateEvent(commandContext.player, string, faction);
        Bukkit.getServer().getPluginManager().callEvent((Event)factionCreateEvent);
        for (FPlayer fPlayer : FPlayers.getInstance().getOnlinePlayers()) {
            fPlayer.msg(TL.COMMAND_CREATE_CREATED, commandContext.fPlayer.describeTo(fPlayer, true), faction.getTag(fPlayer));
        }
        commandContext.msg(TL.COMMAND_CREATE_YOUSHOULD, FCmdRoot.getInstance().cmdDescription.getUsageTemplate(commandContext));
        if (FactionsPlugin.getInstance().conf().logging().isFactionCreate()) {
            FactionsPlugin.getInstance().log(commandContext.fPlayer.getName() + String.valueOf((Object)TL.COMMAND_CREATE_CREATEDLOG) + string);
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_CREATE_DESCRIPTION;
    }
}

