/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.cmd.dtr.CmdDTRGet;
import com.massivecraft.factions.cmd.dtr.CmdDTRModify;
import com.massivecraft.factions.cmd.dtr.CmdDTRResetAll;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdDTR
extends FCommand {
    private final CmdDTRGet cmdDTRGet;

    public CmdDTR() {
        this.aliases.add("dtr");
        this.aliases.add("deathstilraidable");
        this.cmdDTRGet = new CmdDTRGet();
        this.addSubCommand(this.cmdDTRGet);
        this.addSubCommand(new CmdDTRModify());
        this.addSubCommand(new CmdDTRResetAll());
        this.requirements = new CommandRequirements.Builder(Permission.DTR).noDisableOnLock().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        commandContext.commandChain.add(this);
        this.cmdDTRGet.execute(commandContext);
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_DTR_DESCRIPTION;
    }
}

