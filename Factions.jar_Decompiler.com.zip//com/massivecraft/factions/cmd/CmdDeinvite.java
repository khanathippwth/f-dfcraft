/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCmdRoot;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.PermissibleActions;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import moss.factions.shade.net.kyori.adventure.text.Component;
import moss.factions.shade.net.kyori.adventure.text.ComponentBuilder;
import moss.factions.shade.net.kyori.adventure.text.TextComponent;
import moss.factions.shade.net.kyori.adventure.text.event.ClickEvent;
import moss.factions.shade.net.kyori.adventure.text.event.HoverEventSource;
import moss.factions.shade.net.kyori.adventure.text.format.NamedTextColor;
import moss.factions.shade.net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public class CmdDeinvite
extends FCommand {
    public CmdDeinvite() {
        this.aliases.add("deinvite");
        this.aliases.add("deinv");
        this.optionalArgs.put("player", "player");
        this.requirements = new CommandRequirements.Builder(Permission.DEINVITE).memberOnly().withAction(PermissibleActions.INVITE).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        FPlayer fPlayer = commandContext.argAsBestFPlayerMatch(0);
        if (fPlayer == null) {
            LegacyComponentSerializer legacyComponentSerializer = LegacyComponentSerializer.legacySection();
            Component component = legacyComponentSerializer.deserialize(TL.COMMAND_DEINVITE_CANDEINVITE.toString()).color(NamedTextColor.GOLD);
            for (String string : commandContext.faction.getInvites()) {
                FPlayer fPlayer2 = FPlayers.getInstance().getById(string);
                String string2 = fPlayer2 != null ? fPlayer2.getName() : string;
                component = component.append((ComponentBuilder<?, ?>)((TextComponent.Builder)((TextComponent.Builder)Component.text().color(NamedTextColor.GRAY)).content(string2 + " ").hoverEvent((HoverEventSource)legacyComponentSerializer.deserialize(TL.COMMAND_DEINVITE_CLICKTODEINVITE.format(string2)).asHoverEvent())).clickEvent(ClickEvent.runCommand("/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " deinvite " + string2)));
            }
            FactionsPlugin.getInstance().getAdventure().player(commandContext.player).sendMessage(component);
            return;
        }
        if (fPlayer.getFaction() == commandContext.faction) {
            commandContext.msg(TL.COMMAND_DEINVITE_ALREADYMEMBER, fPlayer.getName(), commandContext.faction.getTag());
            commandContext.msg(TL.COMMAND_DEINVITE_MIGHTWANT, FCmdRoot.getInstance().cmdKick.getUsageTemplate(commandContext));
            return;
        }
        commandContext.faction.deinvite(fPlayer);
        fPlayer.msg(TL.COMMAND_DEINVITE_REVOKED, commandContext.fPlayer.describeTo(fPlayer), commandContext.faction.describeTo(fPlayer));
        commandContext.faction.msg(TL.COMMAND_DEINVITE_REVOKES, commandContext.fPlayer.describeTo(commandContext.faction), fPlayer.describeTo(commandContext.faction));
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_DEINVITE_DESCRIPTION;
    }
}

