/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.PermissibleActions;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdDelWarp
extends FCommand {
    public CmdDelWarp() {
        this.aliases.add("delwarp");
        this.aliases.add("dw");
        this.aliases.add("deletewarp");
        this.requiredArgs.add("warp");
        this.requirements = new CommandRequirements.Builder(Permission.SETWARP).memberOnly().withAction(PermissibleActions.SETWARP).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        String string = commandContext.argAsString(0);
        if (commandContext.faction.isWarp(string)) {
            if (!this.transact(commandContext.fPlayer, commandContext)) {
                return;
            }
            commandContext.faction.removeWarp(string);
            commandContext.msg(TL.COMMAND_DELFWARP_DELETED, string);
        } else {
            commandContext.msg(TL.COMMAND_DELFWARP_INVALID, string);
        }
    }

    private boolean transact(FPlayer fPlayer, CommandContext commandContext) {
        return fPlayer.isAdminBypassing() || commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostDelWarp(), TL.COMMAND_DELFWARP_TODELETE.toString(), TL.COMMAND_DELFWARP_FORDELETE.toString());
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_DELFWARP_DESCRIPTION;
    }
}

