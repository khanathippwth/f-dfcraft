/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCmdRoot;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.PermissibleActions;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdDelhome
extends FCommand {
    public CmdDelhome() {
        this.aliases.add("delhome");
        this.requirements = new CommandRequirements.Builder(Permission.DELHOME).memberOnly().withAction(PermissibleActions.SETHOME).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        if (!FactionsPlugin.getInstance().conf().factions().homes().isEnabled()) {
            commandContext.msg(TL.COMMAND_SETHOME_DISABLED, new Object[0]);
            return;
        }
        if (!commandContext.faction.hasHome()) {
            commandContext.msg(String.valueOf((Object)TL.COMMAND_HOME_NOHOME) + (commandContext.fPlayer.getRole().value < Role.MODERATOR.value ? TL.GENERIC_ASKYOURLEADER.toString() : TL.GENERIC_YOUSHOULD.toString()), new Object[0]);
            commandContext.sendMessage(FCmdRoot.getInstance().cmdSethome.getUsageTemplate(commandContext));
            return;
        }
        if (FactionsPlugin.getInstance().conf().factions().homes().isRequiredToHaveHomeBeforeSettingWarps() && !commandContext.faction.getWarps().isEmpty()) {
            commandContext.msg(TL.COMMAND_HOME_WARPSREMAIN, new Object[0]);
            return;
        }
        if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostDelhome(), TL.COMMAND_DELHOME_TOSET, TL.COMMAND_DELHOME_FORSET)) {
            return;
        }
        commandContext.faction.delHome();
        commandContext.faction.msg(TL.COMMAND_DELHOME_DEL, commandContext.fPlayer.describeTo(commandContext.faction, true));
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_DELHOME_DESCRIPTION;
    }
}

