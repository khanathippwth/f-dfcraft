/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.BrigadierProvider;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import com.massivecraft.factions.util.TextUtil;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;

public class CmdDescription
extends FCommand {
    public CmdDescription() {
        this.aliases.add("desc");
        this.aliases.add("description");
        this.requiredArgs.add("desc");
        this.requirements = new CommandRequirements.Builder(Permission.DESCRIPTION).memberOnly().withRole(Role.MODERATOR).noErrorOnManyArgs().brigadier(GreedyMessageBrigadier.class).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostDesc(), TL.COMMAND_DESCRIPTION_TOCHANGE, TL.COMMAND_DESCRIPTION_FORCHANGE)) {
            return;
        }
        String string = TextUtil.implode(commandContext.args, " ").replaceAll("%", "").replaceAll("(&([a-f0-9klmnor]))", "& $2");
        int n = this.plugin.conf().commands().description().getMaxLength();
        if (n > 0 && string.length() > n) {
            commandContext.msg(TL.COMMAND_DESCRIPTION_TOOLONG, String.valueOf(n));
            return;
        }
        commandContext.faction.setDescription(string);
        if (!FactionsPlugin.getInstance().conf().factions().chat().isBroadcastDescriptionChanges()) {
            commandContext.fPlayer.msg(TL.COMMAND_DESCRIPTION_CHANGED, commandContext.faction.describeTo(commandContext.fPlayer));
            commandContext.fPlayer.sendMessage(commandContext.faction.getDescription());
            return;
        }
        for (FPlayer fPlayer : FPlayers.getInstance().getOnlinePlayers()) {
            fPlayer.msg(TL.COMMAND_DESCRIPTION_CHANGES, commandContext.faction.describeTo(fPlayer));
            fPlayer.sendMessage(commandContext.faction.getDescription());
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_DESCRIPTION_DESCRIPTION;
    }

    protected static class GreedyMessageBrigadier
    implements BrigadierProvider {
        protected GreedyMessageBrigadier() {
        }

        @Override
        public ArgumentBuilder<Object, ?> get(ArgumentBuilder<Object, ?> argumentBuilder) {
            return argumentBuilder.then((ArgumentBuilder)RequiredArgumentBuilder.argument((String)"message", (ArgumentType)StringArgumentType.greedyString()));
        }
    }
}

