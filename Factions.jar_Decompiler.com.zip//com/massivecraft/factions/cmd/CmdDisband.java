/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.event.Event
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.Factions;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.event.FPlayerLeaveEvent;
import com.massivecraft.factions.event.FactionDisbandEvent;
import com.massivecraft.factions.integration.Econ;
import com.massivecraft.factions.perms.PermissibleActions;
import com.massivecraft.factions.scoreboards.FTeamWrapper;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;

public class CmdDisband
extends FCommand {
    public CmdDisband() {
        this.aliases.add("disband");
        this.optionalArgs.put("faction", "yours");
        this.requirements = new CommandRequirements.Builder(Permission.DISBAND).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        String string;
        boolean bl;
        Faction faction = commandContext.argAsFaction(0, commandContext.fPlayer == null ? null : commandContext.faction);
        if (faction == null) {
            return;
        }
        boolean bl2 = bl = commandContext.fPlayer != null && faction == commandContext.faction;
        if (bl) {
            if (!faction.hasAccess(commandContext.fPlayer, PermissibleActions.DISBAND, commandContext.fPlayer.getLastStoodAt())) {
                commandContext.msg(TL.GENERIC_NOPERMISSION.format(PermissibleActions.DISBAND.getShortDescription()), new Object[0]);
                return;
            }
        } else if (!Permission.DISBAND_ANY.has(commandContext.sender, true)) {
            return;
        }
        if (!faction.isNormal()) {
            commandContext.msg(TL.COMMAND_DISBAND_IMMUTABLE.toString(), new Object[0]);
            return;
        }
        if (faction.isPermanent()) {
            commandContext.msg(TL.COMMAND_DISBAND_MARKEDPERMANENT.toString(), new Object[0]);
            return;
        }
        if (!FactionsPlugin.getInstance().getLandRaidControl().canDisbandFaction(faction, commandContext)) {
            return;
        }
        FactionDisbandEvent factionDisbandEvent = new FactionDisbandEvent(commandContext.player, faction);
        Bukkit.getServer().getPluginManager().callEvent((Event)factionDisbandEvent);
        if (factionDisbandEvent.isCancelled()) {
            return;
        }
        for (FPlayer fPlayer : faction.getFPlayers()) {
            Bukkit.getServer().getPluginManager().callEvent((Event)new FPlayerLeaveEvent(fPlayer, faction, FPlayerLeaveEvent.PlayerLeaveReason.DISBAND));
        }
        for (FPlayer fPlayer : FPlayers.getInstance().getOnlinePlayers()) {
            String string2 = string = commandContext.player == null ? TL.GENERIC_SERVERADMIN.toString() : commandContext.fPlayer.describeTo(fPlayer);
            if (fPlayer.getFaction() == faction) {
                fPlayer.msg(TL.COMMAND_DISBAND_BROADCAST_YOURS, string);
                continue;
            }
            fPlayer.msg(TL.COMMAND_DISBAND_BROADCAST_NOTYOURS, string, faction.getTag(fPlayer));
        }
        if (FactionsPlugin.getInstance().conf().logging().isFactionDisband()) {
            FactionsPlugin.getInstance().log("The faction " + faction.getTag() + " (" + faction.getIntId() + ") was disbanded by " + (commandContext.player == null ? "console command" : commandContext.fPlayer.getName()) + ".");
        }
        if (Econ.shouldBeUsed() && commandContext.player != null && FactionsPlugin.getInstance().conf().economy().isBankEnabled()) {
            double d = Econ.getBalance(faction);
            Econ.transferMoney(commandContext.fPlayer, faction, commandContext.fPlayer, d, false);
            if (d > 0.0) {
                string = Econ.moneyString(d);
                commandContext.msg(TL.COMMAND_DISBAND_HOLDINGS, string);
                FactionsPlugin.getInstance().log(commandContext.fPlayer.getName() + " has been given bank holdings of " + string + " from disbanding " + faction.getTag() + ".");
            }
        }
        Factions.getInstance().removeFaction(faction);
        FTeamWrapper.applyUpdates(faction);
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_DISBAND_DESCRIPTION;
    }
}

