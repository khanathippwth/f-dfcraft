/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.Board;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.FlightUtil;
import com.massivecraft.factions.util.TL;
import com.massivecraft.factions.util.WarmUpUtil;
import org.bukkit.command.CommandSender;

public class CmdFly
extends FCommand {
    public CmdFly() {
        this.aliases.add("fly");
        this.optionalArgs.put("on/off/auto", "flip");
        this.requirements = new CommandRequirements.Builder(Permission.FLY).memberOnly().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        if (commandContext.args.isEmpty()) {
            this.toggleFlight(commandContext, !commandContext.fPlayer.isFlying(), true);
        } else if (commandContext.args.size() == 1) {
            if (commandContext.argAsString(0).equalsIgnoreCase("auto")) {
                if (Permission.FLY_AUTO.has((CommandSender)commandContext.player, true)) {
                    commandContext.fPlayer.setAutoFlying(!commandContext.fPlayer.isAutoFlying());
                    this.toggleFlight(commandContext, commandContext.fPlayer.isAutoFlying(), false);
                }
            } else {
                this.toggleFlight(commandContext, commandContext.argAsBool(0), true);
            }
        }
    }

    private void toggleFlight(CommandContext commandContext, boolean bl, boolean bl2) {
        if (!bl) {
            commandContext.fPlayer.setFlying(false);
            return;
        }
        if (!this.flyTest(commandContext, bl2)) {
            return;
        }
        commandContext.doWarmUp(WarmUpUtil.Warmup.FLIGHT, TL.WARMUPS_NOTIFY_FLIGHT, "Fly", () -> {
            if (this.flyTest(commandContext, bl2)) {
                commandContext.fPlayer.setFlying(true);
            }
        }, this.plugin.conf().commands().fly().getDelay());
    }

    private boolean flyTest(CommandContext commandContext, boolean bl) {
        if (!commandContext.fPlayer.canFlyAtLocation()) {
            if (bl) {
                Faction faction = Board.getInstance().getFactionAt(commandContext.fPlayer.getLastStoodAt());
                commandContext.msg(TL.COMMAND_FLY_NO_ACCESS, faction.getTag(commandContext.fPlayer));
            }
            return false;
        }
        if (FlightUtil.instance().enemiesNearby(commandContext.fPlayer, FactionsPlugin.getInstance().conf().commands().fly().getEnemyRadius())) {
            if (bl) {
                commandContext.msg(TL.COMMAND_FLY_ENEMY_NEARBY, new Object[0]);
            }
            return false;
        }
        return true;
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_FLY_DESCRIPTION;
    }
}

