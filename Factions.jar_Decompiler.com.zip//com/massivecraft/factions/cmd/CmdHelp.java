/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCmdRoot;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.integration.Econ;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CmdHelp
extends FCommand {
    public ArrayList<ArrayList<String>> helpPages;

    public CmdHelp() {
        this.aliases.add("help");
        this.aliases.add("h");
        this.optionalArgs.put("page", "1");
        this.requirements = new CommandRequirements.Builder(Permission.HELP).noDisableOnLock().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        String string;
        if (FactionsPlugin.getInstance().conf().commands().help().isUseOldHelp()) {
            if (this.helpPages == null) {
                this.updateHelp(commandContext);
            }
            int n = commandContext.argAsInt(0, 1);
            commandContext.sendMessage(this.plugin.txt().titleize("Factions Help (" + n + "/" + this.helpPages.size() + ")"));
            if (--n < 0 || n >= this.helpPages.size()) {
                commandContext.msg(TL.COMMAND_HELP_404.format(String.valueOf(n)), new Object[0]);
                return;
            }
            commandContext.sendMessage((List<String>)this.helpPages.get(n));
            return;
        }
        Map<String, List<String>> map = FactionsPlugin.getInstance().conf().commands().help().getEntries();
        List<String> list = map.get(string = commandContext.argAsString(0, "1"));
        if (list == null || list.isEmpty()) {
            commandContext.msg(TL.COMMAND_HELP_404.format(string), new Object[0]);
            return;
        }
        for (String string2 : list) {
            commandContext.sendMessage(FactionsPlugin.getInstance().txt().parse(string2));
        }
    }

    public void updateHelp(CommandContext commandContext) {
        this.helpPages = new ArrayList();
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add(FCmdRoot.getInstance().cmdHelp.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdList.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdShow.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdPower.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdJoin.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdLeave.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdChat.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdToggleAllianceChat.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdHome.getUsageTemplate(commandContext, true));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_NEXTCREATE.toString()));
        this.helpPages.add(arrayList);
        arrayList = new ArrayList();
        arrayList.add(FCmdRoot.getInstance().cmdCreate.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdDescription.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdTag.getUsageTemplate(commandContext, true));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_INVITATIONS.toString()));
        arrayList.add(FCmdRoot.getInstance().cmdOpen.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdInvite.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdDeinvite.getUsageTemplate(commandContext, true));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_HOME.toString()));
        arrayList.add(FCmdRoot.getInstance().cmdSethome.getUsageTemplate(commandContext, true));
        this.helpPages.add(arrayList);
        if (Econ.isSetup() && FactionsPlugin.getInstance().conf().economy().isEnabled() && FactionsPlugin.getInstance().conf().economy().isBankEnabled()) {
            arrayList = new ArrayList();
            arrayList.add("");
            arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_BANK_1.toString()));
            arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_BANK_2.toString()));
            arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_BANK_3.toString()));
            arrayList.add("");
            arrayList.add(FCmdRoot.getInstance().cmdMoney.getUsageTemplate(commandContext, true));
            arrayList.add("");
            arrayList.add("");
            arrayList.add("");
            this.helpPages.add(arrayList);
        }
        arrayList = new ArrayList();
        arrayList.add(FCmdRoot.getInstance().cmdClaim.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdAutoClaim.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdUnclaim.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdUnclaimall.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdKick.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdMod.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdAdmin.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdTitle.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdSB.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdSeeChunk.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdStatus.getUsageTemplate(commandContext, true));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_PLAYERTITLES.toString()));
        this.helpPages.add(arrayList);
        arrayList = new ArrayList();
        arrayList.add(FCmdRoot.getInstance().cmdMap.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdBoom.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdOwner.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdOwnerList.getUsageTemplate(commandContext, true));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_OWNERSHIP_1.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_OWNERSHIP_2.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_OWNERSHIP_3.toString()));
        this.helpPages.add(arrayList);
        arrayList = new ArrayList();
        arrayList.add(FCmdRoot.getInstance().cmdDisband.getUsageTemplate(commandContext, true));
        arrayList.add("");
        arrayList.add(FCmdRoot.getInstance().cmdRelationAlly.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdRelationNeutral.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdRelationEnemy.getUsageTemplate(commandContext, true));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_1.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_2.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_3.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_4.toString()));
        this.helpPages.add(arrayList);
        arrayList = new ArrayList();
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_5.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_6.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_7.toString()));
        arrayList.add(TL.COMMAND_HELP_RELATIONS_8.toString());
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_9.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_10.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_11.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_12.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_RELATIONS_13.toString()));
        this.helpPages.add(arrayList);
        arrayList = new ArrayList();
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_PERMISSIONS_1.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_PERMISSIONS_2.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_PERMISSIONS_3.toString()));
        arrayList.add(TL.COMMAND_HELP_PERMISSIONS_4.toString());
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_PERMISSIONS_5.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_PERMISSIONS_6.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_PERMISSIONS_7.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_PERMISSIONS_8.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_PERMISSIONS_9.toString()));
        this.helpPages.add(arrayList);
        arrayList = new ArrayList();
        arrayList.add(TL.COMMAND_HELP_MOAR_1.toString());
        arrayList.add(FCmdRoot.getInstance().cmdBypass.getUsageTemplate(commandContext, true));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_ADMIN_1.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_ADMIN_2.toString()));
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_ADMIN_3.toString()));
        arrayList.add(FCmdRoot.getInstance().cmdSafeunclaimall.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdWarunclaimall.getUsageTemplate(commandContext, true));
        arrayList.add(this.plugin.txt().parse("<i>Note: " + FCmdRoot.getInstance().cmdUnclaim.getUsageTemplate(commandContext, false) + FactionsPlugin.getInstance().txt().parse("<i>") + " works on safe/war zones as well."));
        arrayList.add(FCmdRoot.getInstance().cmdPeaceful.getUsageTemplate(commandContext, true));
        this.helpPages.add(arrayList);
        arrayList = new ArrayList();
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_MOAR_2.toString()));
        arrayList.add(FCmdRoot.getInstance().cmdChatSpy.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdPermanent.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdPermanentPower.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdPowerBoost.getUsageTemplate(commandContext, true));
        this.helpPages.add(arrayList);
        arrayList = new ArrayList();
        arrayList.add(this.plugin.txt().parse(TL.COMMAND_HELP_MOAR_3.toString()));
        arrayList.add(FCmdRoot.getInstance().cmdLock.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdReload.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdSaveAll.getUsageTemplate(commandContext, true));
        arrayList.add(FCmdRoot.getInstance().cmdVersion.getUsageTemplate(commandContext, true));
        this.helpPages.add(arrayList);
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_HELP_DESCRIPTION;
    }
}

