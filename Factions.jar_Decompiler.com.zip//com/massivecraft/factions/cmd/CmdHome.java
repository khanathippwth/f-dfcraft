/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.Board;
import com.massivecraft.factions.FLocation;
import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCmdRoot;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.event.FPlayerTeleportEvent;
import com.massivecraft.factions.integration.Essentials;
import com.massivecraft.factions.integration.IntegrationManager;
import com.massivecraft.factions.perms.PermissibleActions;
import com.massivecraft.factions.perms.Relation;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.SmokeUtil;
import com.massivecraft.factions.util.TL;
import com.massivecraft.factions.util.WarmUpUtil;
import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

public class CmdHome
extends FCommand {
    public CmdHome() {
        this.aliases.add("home");
        this.optionalArgs.put("faction", "yours");
        this.requirements = new CommandRequirements.Builder(Permission.HOME).playerOnly().noDisableOnLock().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        Location location;
        Faction faction = commandContext.argAsFaction(0, commandContext.fPlayer == null ? null : commandContext.faction);
        if (faction != commandContext.faction && commandContext.fPlayer.isAdminBypassing()) {
            if (faction.hasHome()) {
                FactionsPlugin.getInstance().teleport(commandContext.player, faction.getHome());
            } else {
                commandContext.fPlayer.msg(TL.COMMAND_HOME_NOHOME, new Object[0]);
            }
            return;
        }
        if (!FactionsPlugin.getInstance().conf().factions().homes().isEnabled()) {
            commandContext.fPlayer.msg(TL.COMMAND_HOME_DISABLED, new Object[0]);
            return;
        }
        if (!FactionsPlugin.getInstance().conf().factions().homes().isTeleportCommandEnabled()) {
            commandContext.fPlayer.msg(TL.COMMAND_HOME_TELEPORTDISABLED, new Object[0]);
            return;
        }
        if (!faction.hasHome()) {
            if (faction == commandContext.faction) {
                if (commandContext.faction.hasAccess(commandContext.fPlayer, PermissibleActions.SETHOME, commandContext.fPlayer.getLastStoodAt())) {
                    commandContext.fPlayer.msg(TL.COMMAND_HOME_NOHOME.toString() + String.valueOf((Object)TL.GENERIC_YOUSHOULD), new Object[0]);
                } else {
                    commandContext.fPlayer.msg(TL.COMMAND_HOME_NOHOME.toString() + String.valueOf((Object)TL.GENERIC_ASKYOURLEADER), new Object[0]);
                }
                commandContext.fPlayer.sendMessage(FCmdRoot.getInstance().cmdSethome.getUsageTemplate(commandContext));
            } else {
                commandContext.fPlayer.msg(TL.COMMAND_HOME_NOHOME, new Object[0]);
            }
            return;
        }
        if (!faction.hasAccess(commandContext.fPlayer, PermissibleActions.HOME, commandContext.fPlayer.getLastStoodAt())) {
            commandContext.fPlayer.msg(TL.COMMAND_HOME_DENIED, faction.getTag(commandContext.fPlayer));
            return;
        }
        if (!FactionsPlugin.getInstance().conf().factions().homes().isTeleportAllowedFromEnemyTerritory() && commandContext.fPlayer.isInEnemyTerritory()) {
            commandContext.fPlayer.msg(TL.COMMAND_HOME_INENEMY, new Object[0]);
            return;
        }
        if (!FactionsPlugin.getInstance().conf().factions().homes().isTeleportAllowedFromDifferentWorld() && commandContext.player.getWorld().getUID() != faction.getHome().getWorld().getUID()) {
            commandContext.fPlayer.msg(TL.COMMAND_HOME_WRONGWORLD, new Object[0]);
            return;
        }
        Faction faction2 = Board.getInstance().getFactionAt(new FLocation(commandContext.player.getLocation()));
        Location location2 = commandContext.player.getLocation().clone();
        if (!(!(FactionsPlugin.getInstance().conf().factions().homes().getTeleportAllowedEnemyDistance() > 0.0) || faction2.isSafeZone() || commandContext.fPlayer.isInOwnTerritory() && FactionsPlugin.getInstance().conf().factions().homes().isTeleportIgnoreEnemiesIfInOwnTerritory())) {
            location = location2.getWorld();
            double d = location2.getX();
            double d2 = location2.getY();
            double d3 = location2.getZ();
            for (Player player : commandContext.player.getServer().getOnlinePlayers()) {
                FPlayer fPlayer;
                if (player == null || !player.isOnline() || player.isDead() || player == commandContext.player || player.getWorld() != location || commandContext.fPlayer.getRelationTo(fPlayer = FPlayers.getInstance().getByPlayer(player)) != Relation.ENEMY || fPlayer.isVanished()) continue;
                Location location3 = player.getLocation();
                double d4 = Math.abs(d - location3.getX());
                double d5 = Math.abs(d2 - location3.getY());
                double d6 = Math.abs(d3 - location3.getZ());
                double d7 = FactionsPlugin.getInstance().conf().factions().homes().getTeleportAllowedEnemyDistance();
                if (d4 > d7 || d5 > d7 || d6 > d7) continue;
                commandContext.fPlayer.msg(TL.COMMAND_HOME_ENEMYNEAR, String.valueOf(FactionsPlugin.getInstance().conf().factions().homes().getTeleportAllowedEnemyDistance()));
                return;
            }
        }
        location = faction.getHome();
        FPlayerTeleportEvent fPlayerTeleportEvent = new FPlayerTeleportEvent(commandContext.fPlayer, location, FPlayerTeleportEvent.PlayerTeleportReason.HOME);
        Bukkit.getServer().getPluginManager().callEvent((Event)fPlayerTeleportEvent);
        if (fPlayerTeleportEvent.isCancelled()) {
            return;
        }
        if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostHome(), TL.COMMAND_HOME_TOTELEPORT.toString(), TL.COMMAND_HOME_FORTELEPORT.toString())) {
            return;
        }
        if (FactionsPlugin.getInstance().getIntegrationManager().isEnabled(IntegrationManager.Integration.ESS) && Essentials.handleTeleport(commandContext.player, location)) {
            return;
        }
        commandContext.doWarmUp(WarmUpUtil.Warmup.HOME, TL.WARMUPS_NOTIFY_TELEPORT, "Home", () -> {
            if (FactionsPlugin.getInstance().conf().factions().homes().isTeleportCommandSmokeEffectEnabled()) {
                ArrayList<Location> arrayList = new ArrayList<Location>();
                arrayList.add(location2);
                arrayList.add(location2.add(0.0, 1.0, 0.0));
                arrayList.add(location);
                arrayList.add(location.clone().add(0.0, 1.0, 0.0));
                SmokeUtil.spawnCloudRandom(arrayList, FactionsPlugin.getInstance().conf().factions().homes().getTeleportCommandSmokeEffectThickness());
            }
            FactionsPlugin.getInstance().teleport(commandContext.player, location);
        }, this.plugin.conf().commands().home().getDelay());
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_HOME_DESCRIPTION;
    }
}

