/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCmdRoot;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.PermissibleActions;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import moss.factions.shade.net.kyori.adventure.text.Component;
import moss.factions.shade.net.kyori.adventure.text.TextComponent;
import moss.factions.shade.net.kyori.adventure.text.event.ClickEvent;
import moss.factions.shade.net.kyori.adventure.text.event.HoverEventSource;
import moss.factions.shade.net.kyori.adventure.text.format.NamedTextColor;
import moss.factions.shade.net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;

public class CmdInvite
extends FCommand {
    public CmdInvite() {
        this.aliases.add("invite");
        this.aliases.add("inv");
        this.requiredArgs.add("player");
        this.requirements = new CommandRequirements.Builder(Permission.INVITE).memberOnly().withAction(PermissibleActions.INVITE).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        FPlayer fPlayer = commandContext.argAsBestFPlayerMatch(0);
        if (fPlayer == null) {
            return;
        }
        if (fPlayer.getFaction() == commandContext.faction) {
            commandContext.msg(TL.COMMAND_INVITE_ALREADYMEMBER, fPlayer.getName(), commandContext.faction.getTag());
            commandContext.msg(String.valueOf((Object)TL.GENERIC_YOUMAYWANT) + FCmdRoot.getInstance().cmdKick.getUsageTemplate(commandContext), new Object[0]);
            return;
        }
        if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostInvite(), TL.COMMAND_INVITE_TOINVITE.toString(), TL.COMMAND_INVITE_FORINVITE.toString())) {
            return;
        }
        if (commandContext.faction.isBanned(fPlayer)) {
            commandContext.msg(TL.COMMAND_INVITE_BANNED, fPlayer.getName());
            return;
        }
        commandContext.faction.invite(fPlayer);
        if (fPlayer.isOnline()) {
            LegacyComponentSerializer legacyComponentSerializer = LegacyComponentSerializer.legacySection();
            Component component = ((TextComponent)legacyComponentSerializer.deserialize(commandContext.fPlayer.describeTo(fPlayer, true)).append(legacyComponentSerializer.deserialize(TL.COMMAND_INVITE_INVITEDYOU.toString()).color(NamedTextColor.YELLOW))).append(legacyComponentSerializer.deserialize(commandContext.faction.describeTo(fPlayer)));
            component = component.hoverEvent((HoverEventSource)legacyComponentSerializer.deserialize(TL.COMMAND_INVITE_CLICKTOJOIN.toString()).asHoverEvent()).clickEvent(ClickEvent.runCommand("/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " join " + ChatColor.stripColor((String)commandContext.faction.getTag())));
            FactionsPlugin.getInstance().getAdventure().player(fPlayer.getPlayer()).sendMessage(component);
        }
        commandContext.faction.msg(TL.COMMAND_INVITE_INVITED, commandContext.fPlayer.describeTo(commandContext.faction, true), fPlayer.describeTo(commandContext.faction));
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_INVITE_DESCRIPTION;
    }
}

