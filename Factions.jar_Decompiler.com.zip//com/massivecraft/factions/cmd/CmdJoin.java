/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.event.Event
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.event.FPlayerJoinEvent;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;

public class CmdJoin
extends FCommand {
    public CmdJoin() {
        this.aliases.add("join");
        this.requiredArgs.add("faction");
        this.optionalArgs.put("player", "you");
        this.requirements = new CommandRequirements.Builder(Permission.JOIN).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        boolean bl;
        Faction faction = commandContext.argAsFaction(0);
        if (faction == null) {
            return;
        }
        FPlayer fPlayer = commandContext.argAsBestFPlayerMatch(1, commandContext.fPlayer, false);
        if (fPlayer == null) {
            return;
        }
        boolean bl2 = bl = fPlayer == commandContext.fPlayer;
        if (!bl && !Permission.JOIN_OTHERS.has(commandContext.sender, false)) {
            commandContext.msg(TL.COMMAND_JOIN_CANNOTFORCE, new Object[0]);
            return;
        }
        if (!faction.isNormal()) {
            commandContext.msg(TL.COMMAND_JOIN_SYSTEMFACTION, new Object[0]);
            return;
        }
        if (faction == fPlayer.getFaction()) {
            commandContext.msg(TL.COMMAND_JOIN_ALREADYMEMBER, fPlayer.describeTo(fPlayer, true), bl ? "are" : "is", faction.getTag(commandContext.fPlayer));
            return;
        }
        if (FactionsPlugin.getInstance().conf().factions().other().getFactionMemberLimit() > 0 && faction.getFPlayers().size() >= FactionsPlugin.getInstance().conf().factions().other().getFactionMemberLimit()) {
            commandContext.msg(TL.COMMAND_JOIN_ATLIMIT, faction.getTag(fPlayer), FactionsPlugin.getInstance().conf().factions().other().getFactionMemberLimit(), fPlayer.describeTo(commandContext.fPlayer, false));
            return;
        }
        if (fPlayer.hasFaction()) {
            commandContext.msg(TL.COMMAND_JOIN_INOTHERFACTION, fPlayer.describeTo(fPlayer, true), bl ? "your" : "their");
            return;
        }
        if (!FactionsPlugin.getInstance().getLandRaidControl().canJoinFaction(faction, fPlayer, commandContext)) {
            return;
        }
        if (!(faction.getOpen() || faction.isInvited(fPlayer) || commandContext.fPlayer == null || commandContext.fPlayer.isAdminBypassing() || Permission.JOIN_ANY.has(commandContext.sender, false))) {
            commandContext.msg(TL.COMMAND_JOIN_REQUIRESINVITATION, new Object[0]);
            if (bl && !faction.isBanned(fPlayer)) {
                faction.msg(TL.COMMAND_JOIN_ATTEMPTEDJOIN, fPlayer.describeTo(faction, true));
            }
            return;
        }
        if (bl && !commandContext.canAffordCommand(FactionsPlugin.getInstance().conf().economy().getCostJoin(), TL.COMMAND_JOIN_TOJOIN.toString())) {
            return;
        }
        if (commandContext.fPlayer != null && !commandContext.fPlayer.isAdminBypassing() && faction.isBanned(fPlayer)) {
            commandContext.msg(TL.COMMAND_JOIN_BANNED, faction.getTag(commandContext.fPlayer));
            return;
        }
        FPlayerJoinEvent fPlayerJoinEvent = new FPlayerJoinEvent(fPlayer, faction, FPlayerJoinEvent.PlayerJoinReason.COMMAND);
        Bukkit.getServer().getPluginManager().callEvent((Event)fPlayerJoinEvent);
        if (fPlayerJoinEvent.isCancelled()) {
            return;
        }
        if (bl && !commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostJoin(), TL.COMMAND_JOIN_TOJOIN.toString(), TL.COMMAND_JOIN_FORJOIN.toString())) {
            return;
        }
        fPlayer.msg(TL.COMMAND_JOIN_SUCCESS, fPlayer.describeTo(fPlayer, true), faction.getTag(fPlayer));
        if (!bl) {
            fPlayer.msg(TL.COMMAND_JOIN_MOVED, commandContext.fPlayer == null ? TL.GENERIC_SERVERADMIN : commandContext.fPlayer.describeTo(fPlayer, true), faction.getTag(fPlayer));
        }
        faction.msg(TL.COMMAND_JOIN_JOINED, fPlayer.describeTo(faction, true));
        fPlayer.resetFactionData();
        fPlayer.setFaction(faction);
        faction.deinvite(fPlayer);
        fPlayer.setRole(faction.getDefaultRole());
        if (FactionsPlugin.getInstance().conf().logging().isFactionJoin()) {
            if (bl) {
                FactionsPlugin.getInstance().log(TL.COMMAND_JOIN_JOINEDLOG.toString(), fPlayer.getName(), faction.getTag());
            } else {
                FactionsPlugin.getInstance().log(TL.COMMAND_JOIN_MOVEDLOG.toString(), commandContext.fPlayer == null ? TL.GENERIC_SERVERADMIN : commandContext.fPlayer.getName(), fPlayer.getName(), faction.getTag());
            }
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_JOIN_DESCRIPTION;
    }
}

