/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.event.Event
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCmdRoot;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.event.FPlayerLeaveEvent;
import com.massivecraft.factions.perms.PermissibleActions;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import moss.factions.shade.net.kyori.adventure.text.Component;
import moss.factions.shade.net.kyori.adventure.text.ComponentBuilder;
import moss.factions.shade.net.kyori.adventure.text.TextComponent;
import moss.factions.shade.net.kyori.adventure.text.event.ClickEvent;
import moss.factions.shade.net.kyori.adventure.text.event.HoverEventSource;
import moss.factions.shade.net.kyori.adventure.text.format.NamedTextColor;
import moss.factions.shade.net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;

public class CmdKick
extends FCommand {
    public CmdKick() {
        this.aliases.add("kick");
        this.optionalArgs.put("player", "player");
        this.requirements = new CommandRequirements.Builder(Permission.KICK).memberOnly().withAction(PermissibleActions.KICK).noDisableOnLock().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        FPlayer fPlayer;
        FPlayer fPlayer2 = fPlayer = commandContext.argIsSet(0) ? commandContext.argAsBestFPlayerMatch(0) : null;
        if (fPlayer == null) {
            String string;
            LegacyComponentSerializer legacyComponentSerializer = LegacyComponentSerializer.legacySection();
            Component component = legacyComponentSerializer.deserialize(TL.COMMAND_KICK_CANDIDATES.toString()).color(NamedTextColor.GOLD);
            for (FPlayer fPlayer3 : commandContext.faction.getFPlayersWhereRole(Role.NORMAL)) {
                string = fPlayer3.getName();
                component = component.append((ComponentBuilder<?, ?>)((TextComponent.Builder)((TextComponent.Builder)Component.text().color(NamedTextColor.WHITE)).content(string + " ").hoverEvent((HoverEventSource)legacyComponentSerializer.deserialize(String.valueOf((Object)TL.COMMAND_KICK_CLICKTOKICK) + string).asHoverEvent())).clickEvent(ClickEvent.runCommand("/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " kick " + string)));
            }
            if (commandContext.fPlayer.getRole().isAtLeast(Role.COLEADER)) {
                for (FPlayer fPlayer3 : commandContext.faction.getFPlayersWhereRole(Role.MODERATOR)) {
                    string = fPlayer3.getName();
                    component = component.append((ComponentBuilder<?, ?>)((TextComponent.Builder)((TextComponent.Builder)Component.text().color(NamedTextColor.GRAY)).content(string + " ").hoverEvent((HoverEventSource)legacyComponentSerializer.deserialize(String.valueOf((Object)TL.COMMAND_KICK_CLICKTOKICK) + string).asHoverEvent())).clickEvent(ClickEvent.runCommand("/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " kick " + string)));
                }
                if (commandContext.fPlayer.getRole() == Role.ADMIN) {
                    for (FPlayer fPlayer3 : commandContext.faction.getFPlayersWhereRole(Role.COLEADER)) {
                        string = fPlayer3.getName();
                        component = component.append((ComponentBuilder<?, ?>)((TextComponent.Builder)((TextComponent.Builder)Component.text().color(NamedTextColor.RED)).content(string + " ").hoverEvent((HoverEventSource)legacyComponentSerializer.deserialize(String.valueOf((Object)TL.COMMAND_KICK_CLICKTOKICK) + string).asHoverEvent())).clickEvent(ClickEvent.runCommand("/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " kick " + string)));
                    }
                }
            }
            FactionsPlugin.getInstance().getAdventure().player(commandContext.player).sendMessage(component);
            return;
        }
        if (commandContext.fPlayer == fPlayer) {
            commandContext.msg(TL.COMMAND_KICK_SELF, new Object[0]);
            commandContext.msg(String.valueOf((Object)TL.GENERIC_YOUMAYWANT) + FCmdRoot.getInstance().cmdLeave.getUsageTemplate(commandContext), new Object[0]);
            return;
        }
        Faction faction = fPlayer.getFaction();
        if (faction.isWilderness()) {
            commandContext.sender.sendMessage(TL.COMMAND_KICK_NONE.toString());
            return;
        }
        if (!Permission.KICK_ANY.has(commandContext.sender)) {
            if (faction != commandContext.faction) {
                commandContext.msg(TL.COMMAND_KICK_NOTMEMBER, fPlayer.describeTo(commandContext.fPlayer, true), commandContext.faction.describeTo(commandContext.fPlayer));
                return;
            }
            if (fPlayer.getRole().value >= commandContext.fPlayer.getRole().value) {
                commandContext.msg(TL.COMMAND_KICK_INSUFFICIENTRANK, new Object[0]);
                return;
            }
            if (!FactionsPlugin.getInstance().getLandRaidControl().canKick(fPlayer, commandContext)) {
                return;
            }
        }
        if (!commandContext.canAffordCommand(FactionsPlugin.getInstance().conf().economy().getCostKick(), TL.COMMAND_KICK_TOKICK.toString())) {
            return;
        }
        FPlayerLeaveEvent fPlayerLeaveEvent = new FPlayerLeaveEvent(fPlayer, fPlayer.getFaction(), FPlayerLeaveEvent.PlayerLeaveReason.KICKED);
        Bukkit.getServer().getPluginManager().callEvent((Event)fPlayerLeaveEvent);
        if (fPlayerLeaveEvent.isCancelled()) {
            return;
        }
        if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostKick(), TL.COMMAND_KICK_TOKICK.toString(), TL.COMMAND_KICK_FORKICK.toString())) {
            return;
        }
        faction.msg(TL.COMMAND_KICK_FACTION, commandContext.fPlayer.describeTo(faction, true), fPlayer.describeTo(faction, true));
        fPlayer.msg(TL.COMMAND_KICK_KICKED, commandContext.fPlayer.describeTo(fPlayer, true), faction.describeTo(fPlayer));
        if (faction != commandContext.faction) {
            commandContext.msg(TL.COMMAND_KICK_KICKS, fPlayer.describeTo(commandContext.fPlayer), faction.describeTo(commandContext.fPlayer));
        }
        if (FactionsPlugin.getInstance().conf().logging().isFactionKick()) {
            FactionsPlugin.getInstance().log((commandContext.player == null ? "A console command" : commandContext.fPlayer.getName()) + " kicked " + fPlayer.getName() + " from the faction: " + faction.getTag());
        }
        if (fPlayer.getRole() == Role.ADMIN) {
            faction.promoteNewLeader();
        }
        faction.deinvite(fPlayer);
        fPlayer.resetFactionData();
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_KICK_DESCRIPTION;
    }
}

