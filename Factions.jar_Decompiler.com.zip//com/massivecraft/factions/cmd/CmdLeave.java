/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdLeave
extends FCommand {
    public CmdLeave() {
        this.aliases.add("leave");
        this.requirements = new CommandRequirements.Builder(Permission.LEAVE).memberOnly().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        commandContext.fPlayer.leave(true);
    }

    @Override
    public TL getUsageTranslation() {
        return TL.LEAVE_DESCRIPTION;
    }
}

