/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.ArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.cmd.BrigadierProvider;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import com.massivecraft.factions.util.TextUtil;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.util.Iterator;

public class CmdLink
extends FCommand {
    public CmdLink() {
        this.aliases.add("link");
        this.optionalArgs.put("URL", "URL");
        this.requirements = new CommandRequirements.Builder(Permission.LINK).memberOnly().noErrorOnManyArgs().brigadier(Brigadier.class).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        if (commandContext.args.isEmpty()) {
            commandContext.msg(TL.COMMAND_LINK_SHOW, this.plugin.conf().colors().relations().getMember(), commandContext.faction.getLink());
            return;
        }
        if (!commandContext.fPlayer.getRole().isAtLeast(Role.MODERATOR)) {
            commandContext.msg(TL.GENERIC_YOUMUSTBE, new Object[]{Role.MODERATOR.translation});
            return;
        }
        String string = TextUtil.implode(commandContext.args, " ").replaceAll("[%\\s]", "").replaceAll("(&([a-f0-9klmnor]))", "& $2");
        if (!string.matches("^https?://.+")) {
            commandContext.msg(TL.COMMAND_LINK_INVALIDURL, new Object[0]);
            return;
        }
        commandContext.faction.setLink(string);
        Iterator<FPlayer> iterator = commandContext.faction.getFPlayersWhereOnline(true).iterator();
        if (iterator.hasNext()) {
            FPlayer fPlayer = iterator.next();
            fPlayer.msg(TL.COMMAND_LINK_CHANGED, commandContext.faction.describeTo(commandContext.fPlayer));
            fPlayer.sendMessage(commandContext.faction.getLink());
            return;
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_LINK_DESCRIPTION;
    }

    protected static class Brigadier
    implements BrigadierProvider {
        protected Brigadier() {
        }

        @Override
        public ArgumentBuilder<Object, ?> get(ArgumentBuilder<Object, ?> argumentBuilder) {
            return argumentBuilder.then((ArgumentBuilder)RequiredArgumentBuilder.argument((String)"URL", (ArgumentType)StringArgumentType.greedyString()));
        }
    }
}

