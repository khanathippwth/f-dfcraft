/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.Faction;
import com.massivecraft.factions.Factions;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.tag.Tag;
import com.massivecraft.factions.util.TL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

public class CmdList
extends FCommand {
    public CmdList() {
        this.aliases.add("list");
        this.aliases.add("ls");
        this.optionalArgs.put("page", "1");
        this.requirements = new CommandRequirements.Builder(Permission.LIST).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        List<String> list;
        if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostList(), "to list the factions", "for listing the factions")) {
            return;
        }
        ArrayList<Faction> arrayList = Factions.getInstance().getAllFactions();
        arrayList.remove(Factions.getInstance().getWilderness());
        arrayList.remove(Factions.getInstance().getSafeZone());
        arrayList.remove(Factions.getInstance().getWarZone());
        if (!commandContext.sender.hasPermission(Permission.SHOW_BYPASS_EXEMPT.toString())) {
            list = FactionsPlugin.getInstance().conf().commands().show().getExempt();
            arrayList.removeIf(faction -> list.contains(faction.getTag()));
        }
        arrayList.sort(this.compare(Faction::getFPlayers));
        arrayList.sort(this.compare(faction -> faction.getFPlayersWhereOnline(true, commandContext.fPlayer)));
        list = new ArrayList<String>();
        arrayList.addFirst(Factions.getInstance().getWilderness());
        int n = 9;
        int n2 = commandContext.argAsInt(0, 1);
        int n3 = arrayList.size() / 9 + 1;
        if (n2 > n3) {
            n2 = n3;
        } else if (n2 < 1) {
            n2 = 1;
        }
        int n4 = (n2 - 1) * 9;
        int n5 = n4 + 9;
        if (n5 > arrayList.size()) {
            n5 = arrayList.size();
        }
        String string = this.plugin.conf().commands().list().getHeader();
        String string2 = this.plugin.conf().commands().list().getFooter();
        if (!string.isEmpty()) {
            string = string.replace("{pagenumber}", String.valueOf(n2)).replace("{pagecount}", String.valueOf(n3));
            ((ArrayList)list).add(this.plugin.txt().parse(string));
        }
        for (Faction faction2 : arrayList.subList(n4, n5)) {
            if (faction2.isWilderness()) {
                ((ArrayList)list).add(this.plugin.txt().parse(Tag.parsePlain(faction2, this.plugin.conf().commands().list().getFactionlessEntry())));
                continue;
            }
            ((ArrayList)list).add(this.plugin.txt().parse(Tag.parsePlain(faction2, commandContext.fPlayer, this.plugin.conf().commands().list().getEntry())));
        }
        if (!string2.isEmpty()) {
            string2 = string2.replace("{pagenumber}", String.valueOf(n2)).replace("{pagecount}", String.valueOf(n3));
            ((ArrayList)list).add(this.plugin.txt().parse(string2));
        }
        commandContext.sendMessage(list);
    }

    private Comparator<Faction> compare(Function<Faction, ? extends Collection<?>> function) {
        return (faction, faction2) -> {
            int n;
            int n2 = ((Collection)function.apply((Faction)faction)).size();
            if (n2 < (n = ((Collection)function.apply((Faction)faction2)).size())) {
                return 1;
            }
            if (n2 > n) {
                return -1;
            }
            return 0;
        };
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_LIST_DESCRIPTION;
    }
}

