/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.Board;
import com.massivecraft.factions.FLocation;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.PermissibleActions;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Queue;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.World;

public class CmdListClaims
extends FCommand {
    public CmdListClaims() {
        this.aliases.add("listclaims");
        this.aliases.add("listclaim");
        this.optionalArgs.put("world", "currentworld");
        this.optionalArgs.put("faction", "yours");
        this.requirements = new CommandRequirements.Builder(Permission.LISTCLAIMS).withAction(PermissibleActions.LISTCLAIMS).memberOnly().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        World world = commandContext.player.getWorld();
        if (commandContext.argIsSet(0)) {
            world = Bukkit.getWorld((String)commandContext.argAsString(0));
        }
        if (world == null) {
            commandContext.msg(TL.COMMAND_LISTCLAIMS_INVALIDWORLD, commandContext.argAsString(0));
            return;
        }
        Faction faction = commandContext.faction;
        if (commandContext.argIsSet(1)) {
            if (Permission.LISTCLAIMS_OTHER.has(commandContext.sender, true)) {
                faction = commandContext.argAsFaction(1);
            } else {
                return;
            }
        }
        if (faction == null) {
            commandContext.msg(TL.GENERIC_NOFACTIONMATCH, commandContext.argAsString(1));
            return;
        }
        HashMap<Long, FLoc> hashMap = new HashMap<Long, FLoc>();
        for (FLocation serializable : Board.getInstance().getAllClaims(faction)) {
            if (!serializable.getWorld().equals((Object)world)) continue;
            hashMap.put(this.getLong(serializable.getX(), (int)serializable.getZ()), new FLoc(serializable.getX(), serializable.getZ()));
        }
        if (hashMap.isEmpty()) {
            commandContext.msg(TL.COMMAND_LISTCLAIMS_NOCLAIMS, faction.getTag(), world.getName());
            return;
        }
        ArrayList<FLoc> arrayList = new ArrayList<FLoc>();
        for (Object object : hashMap.values()) {
            FLoc fLoc;
            if (((FLoc)object).processed) continue;
            HashSet hashSet = new HashSet();
            hashSet.add(object);
            LinkedList<FLoc> linkedList = new LinkedList<FLoc>();
            linkedList.add((FLoc)object);
            while (!linkedList.isEmpty()) {
                fLoc = (FLoc)linkedList.poll();
                fLoc.processed = true;
                this.addIf(hashSet, linkedList, (FLoc)hashMap.get(this.getLong(fLoc.x, fLoc.z + 1)));
                this.addIf(hashSet, linkedList, (FLoc)hashMap.get(this.getLong(fLoc.x, fLoc.z - 1)));
                this.addIf(hashSet, linkedList, (FLoc)hashMap.get(this.getLong(fLoc.x + 1, fLoc.z)));
                this.addIf(hashSet, linkedList, (FLoc)hashMap.get(this.getLong(fLoc.x - 1, fLoc.z)));
            }
            if (hashSet.size() == 1) {
                arrayList.add((FLoc)object);
                continue;
            }
            long l = 0L;
            long fLoc2 = 0L;
            Iterator iterator = hashSet.iterator();
            while (iterator.hasNext()) {
                FLoc fLoc3 = (FLoc)iterator.next();
                l += (long)fLoc3.x;
                fLoc2 += (long)fLoc3.z;
            }
            fLoc = new FLoc((int)((double)l / (double)hashSet.size() + 0.5), (int)((double)fLoc2 / (double)hashSet.size() + 0.5));
            fLoc.total = hashSet.size();
            arrayList.add(fLoc);
        }
        commandContext.msg(TL.COMMAND_LISTCLAIMS_MESSAGE, faction.getTag(), world.getName());
        StringBuilder stringBuilder = new StringBuilder();
        String string = "   ";
        for (FLoc fLoc : arrayList) {
            Object object;
            object = (fLoc.x << 4 | 8) + "," + (fLoc.z << 4 | 8) + (String)(fLoc.total > 1 ? " (" + fLoc.total + ")" : "");
            if (stringBuilder.length() + "   ".length() + ((String)object).length() > 75) {
                commandContext.msg(stringBuilder.toString(), new Object[0]);
                stringBuilder.setLength(0);
            } else if (!stringBuilder.isEmpty()) {
                stringBuilder.append("   ");
            }
            stringBuilder.append((String)object);
        }
        if (!stringBuilder.isEmpty()) {
            commandContext.msg(stringBuilder.toString(), new Object[0]);
        }
    }

    private void addIf(Set<FLoc> set, Queue<FLoc> queue, FLoc fLoc) {
        if (fLoc != null && !set.contains(fLoc)) {
            set.add(fLoc);
            queue.add(fLoc);
        }
    }

    private long getLong(long l, int n) {
        return l << 32 | (long)n;
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_LISTCLAIMS_DESCRIPTION;
    }

    private static class FLoc {
        private final int x;
        private final int z;
        private boolean processed;
        private int total = 1;

        public FLoc(long l, long l2) {
            this.x = (int)l;
            this.z = (int)l2;
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (object == null || this.getClass() != object.getClass()) {
                return false;
            }
            FLoc fLoc = (FLoc)object;
            return this.x == fLoc.x && this.z == fLoc.z;
        }

        public int hashCode() {
            return Objects.hash(this.x, this.z);
        }
    }
}

