/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdLock
extends FCommand {
    public CmdLock() {
        this.aliases.add("lock");
        this.optionalArgs.put("on/off", "flip");
        this.requirements = new CommandRequirements.Builder(Permission.LOCK).noDisableOnLock().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        this.plugin.setLocked(commandContext.argAsBool(0, !this.plugin.getLocked()));
        commandContext.msg(this.plugin.getLocked() ? TL.COMMAND_LOCK_LOCKED : TL.COMMAND_LOCK_UNLOCKED, new Object[0]);
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_LOCK_DESCRIPTION;
    }
}

