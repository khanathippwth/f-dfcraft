/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdLogins
extends FCommand {
    public CmdLogins() {
        this.aliases.add("login");
        this.aliases.add("logins");
        this.aliases.add("logout");
        this.aliases.add("logouts");
        this.requirements = new CommandRequirements.Builder(Permission.MONITOR_LOGINS).memberOnly().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        boolean bl = commandContext.fPlayer.isMonitoringJoins();
        commandContext.msg(TL.COMMAND_LOGINS_TOGGLE, String.valueOf(!bl));
        commandContext.fPlayer.setMonitorJoins(!bl);
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_LOGINS_DESCRIPTION;
    }
}

