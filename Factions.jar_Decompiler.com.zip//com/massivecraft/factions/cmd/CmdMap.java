/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.Board;
import com.massivecraft.factions.FLocation;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import moss.factions.shade.net.kyori.adventure.audience.Audience;
import moss.factions.shade.net.kyori.adventure.text.Component;

public class CmdMap
extends FCommand {
    public CmdMap() {
        this.aliases.add("map");
        this.optionalArgs.put("on/off", "once");
        this.requirements = new CommandRequirements.Builder(Permission.MAP).playerOnly().noDisableOnLock().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        if (commandContext.argIsSet(0)) {
            if (commandContext.argAsBool(0, !commandContext.fPlayer.isMapAutoUpdating()).booleanValue()) {
                if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostMap(), "to show the map", "for showing the map")) {
                    return;
                }
                commandContext.fPlayer.setMapAutoUpdating(true);
                commandContext.msg(TL.COMMAND_MAP_UPDATE_ENABLED, new Object[0]);
                this.showMap(commandContext);
            } else {
                commandContext.fPlayer.setMapAutoUpdating(false);
                commandContext.msg(TL.COMMAND_MAP_UPDATE_DISABLED, new Object[0]);
            }
        } else {
            if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostMap(), TL.COMMAND_MAP_TOSHOW, TL.COMMAND_MAP_FORSHOW)) {
                return;
            }
            this.showMap(commandContext);
        }
    }

    public void showMap(CommandContext commandContext) {
        Audience audience = FactionsPlugin.getInstance().getAdventure().player(commandContext.player);
        for (Component component : Board.getInstance().getMap(commandContext.fPlayer, new FLocation(commandContext.fPlayer), commandContext.fPlayer.getPlayer().getLocation().getYaw())) {
            audience.sendMessage(component);
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_MAP_DESCRIPTION;
    }
}

