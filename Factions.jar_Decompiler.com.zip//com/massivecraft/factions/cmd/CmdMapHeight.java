/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdMapHeight
extends FCommand {
    public CmdMapHeight() {
        this.aliases.add("mapheight");
        this.aliases.add("mh");
        this.optionalArgs.put("height", "height");
        this.requirements = new CommandRequirements.Builder(Permission.MAPHEIGHT).playerOnly().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        if (commandContext.args.isEmpty()) {
            commandContext.fPlayer.sendMessage(TL.COMMAND_MAPHEIGHT_CURRENT.format(commandContext.fPlayer.getMapHeight()));
            return;
        }
        int n = commandContext.argAsInt(0);
        commandContext.fPlayer.setMapHeight(n);
        commandContext.fPlayer.sendMessage(TL.COMMAND_MAPHEIGHT_SET.format(commandContext.fPlayer.getMapHeight()));
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_MAPHEIGHT_DESCRIPTION;
    }
}

