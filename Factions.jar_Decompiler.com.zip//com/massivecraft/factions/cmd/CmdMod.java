/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import moss.factions.shade.net.kyori.adventure.text.Component;
import moss.factions.shade.net.kyori.adventure.text.ComponentBuilder;
import moss.factions.shade.net.kyori.adventure.text.TextComponent;
import moss.factions.shade.net.kyori.adventure.text.event.ClickEvent;
import moss.factions.shade.net.kyori.adventure.text.event.HoverEventSource;
import moss.factions.shade.net.kyori.adventure.text.format.NamedTextColor;
import moss.factions.shade.net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public class CmdMod
extends FCommand {
    public CmdMod() {
        this.aliases.add("mod");
        this.aliases.add("setmod");
        this.aliases.add("officer");
        this.aliases.add("setofficer");
        this.optionalArgs.put("player", "player");
        this.requirements = new CommandRequirements.Builder(Permission.MOD).memberOnly().withRole(Role.COLEADER).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        FPlayer fPlayer = commandContext.argAsBestFPlayerMatch(0);
        if (fPlayer == null) {
            LegacyComponentSerializer legacyComponentSerializer = LegacyComponentSerializer.legacySection();
            Component component = legacyComponentSerializer.deserialize(TL.COMMAND_MOD_CANDIDATES.toString()).color(NamedTextColor.GOLD);
            for (FPlayer fPlayer2 : commandContext.faction.getFPlayersWhereRole(Role.NORMAL)) {
                String string = fPlayer2.getName();
                component = component.append((ComponentBuilder<?, ?>)((TextComponent.Builder)((TextComponent.Builder)Component.text().color(NamedTextColor.WHITE)).content(string + " ").hoverEvent((HoverEventSource)legacyComponentSerializer.deserialize(String.valueOf((Object)TL.COMMAND_MOD_CLICKTOPROMOTE) + string))).clickEvent(ClickEvent.runCommand("/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " mod " + string)));
            }
            FactionsPlugin.getInstance().getAdventure().player(commandContext.player).sendMessage(component);
            return;
        }
        boolean bl = Permission.MOD_ANY.has(commandContext.sender, false);
        Faction faction = fPlayer.getFaction();
        if (faction != commandContext.faction && !bl) {
            commandContext.msg(TL.COMMAND_MOD_NOTMEMBER, fPlayer.describeTo(commandContext.fPlayer, true));
            return;
        }
        if (commandContext.fPlayer != null && !commandContext.fPlayer.getRole().isAtLeast(Role.COLEADER) && !bl) {
            commandContext.msg(TL.COMMAND_MOD_NOTADMIN, new Object[0]);
            return;
        }
        if (fPlayer == commandContext.fPlayer && !bl) {
            commandContext.msg(TL.COMMAND_MOD_SELF, new Object[0]);
            return;
        }
        if (fPlayer.getRole() == Role.ADMIN) {
            commandContext.msg(TL.COMMAND_MOD_TARGETISADMIN, new Object[0]);
            return;
        }
        if (fPlayer.getRole() == Role.MODERATOR) {
            fPlayer.setRole(Role.NORMAL);
            faction.msg(TL.COMMAND_MOD_REVOKED, fPlayer.describeTo(faction, true));
            commandContext.msg(TL.COMMAND_MOD_REVOKES, fPlayer.describeTo(commandContext.fPlayer, true));
        } else {
            fPlayer.setRole(Role.MODERATOR);
            faction.msg(TL.COMMAND_MOD_PROMOTED, fPlayer.describeTo(faction, true));
            commandContext.msg(TL.COMMAND_MOD_PROMOTES, fPlayer.describeTo(commandContext.fPlayer, true));
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_MOD_DESCRIPTION;
    }
}

