/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdModifyPower
extends FCommand {
    public CmdModifyPower() {
        this.aliases.add("pm");
        this.aliases.add("mp");
        this.aliases.add("modifypower");
        this.aliases.add("modpower");
        this.requiredArgs.add("name");
        this.requiredArgs.add("power");
        this.requirements = new CommandRequirements.Builder(Permission.MODIFY_POWER).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        FPlayer fPlayer = commandContext.argAsBestFPlayerMatch(0);
        Double d = commandContext.argAsDouble(1);
        if (fPlayer == null || d == null) {
            commandContext.sender.sendMessage(this.getHelpShort());
            return;
        }
        fPlayer.alterPower(d);
        int n = fPlayer.getPowerRounded();
        commandContext.msg(TL.COMMAND_MODIFYPOWER_ADDED, d, fPlayer.getName(), n);
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_MODIFYPOWER_DESCRIPTION;
    }
}

