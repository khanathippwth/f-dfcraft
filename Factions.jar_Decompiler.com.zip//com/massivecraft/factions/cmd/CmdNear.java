/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.tag.Tag;
import com.massivecraft.factions.util.TL;
import java.util.ArrayList;
import java.util.Set;
import org.bukkit.Location;

public class CmdNear
extends FCommand {
    public CmdNear() {
        this.aliases.add("near");
        this.requirements = new CommandRequirements.Builder(Permission.NEAR).memberOnly().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        int n = FactionsPlugin.getInstance().conf().commands().near().getRadius();
        Set<FPlayer> set = commandContext.faction.getFPlayersWhereOnline(true, commandContext.fPlayer);
        ArrayList<FPlayer> arrayList = new ArrayList<FPlayer>();
        int n2 = n * n;
        Location location = commandContext.player.getLocation();
        Location location2 = new Location(location.getWorld(), 0.0, 0.0, 0.0);
        for (FPlayer object2 : set) {
            if (object2 == commandContext.fPlayer) continue;
            object2.getPlayer().getLocation(location2);
            if (!location2.getWorld().getUID().equals(location.getWorld().getUID()) || !(location2.distanceSquared(location) <= (double)n2)) continue;
            arrayList.add(object2);
        }
        StringBuilder stringBuilder = new StringBuilder();
        String string = TL.COMMAND_NEAR_PLAYER.toString();
        for (FPlayer fPlayer : arrayList) {
            stringBuilder.append(this.parsePlaceholders(commandContext.fPlayer, fPlayer, string));
        }
        if (stringBuilder.toString().isEmpty()) {
            stringBuilder.append((Object)TL.COMMAND_NEAR_NONE);
        }
        commandContext.msg(TL.COMMAND_NEAR_PLAYERLIST.toString().replace("{players-nearby}", stringBuilder.toString()), new Object[0]);
    }

    private String parsePlaceholders(FPlayer fPlayer, FPlayer fPlayer2, String string) {
        string = Tag.parsePlain(fPlayer2, string);
        string = Tag.parsePlaceholders(fPlayer2.getPlayer(), string);
        string = string.replace("{role}", fPlayer2.getRole().toString());
        if ((string = string.replace("{role-prefix}", fPlayer2.getRole().getPrefix())).contains("{distance}")) {
            double d = Math.round(fPlayer.getPlayer().getLocation().distance(fPlayer2.getPlayer().getLocation()));
            string = string.replace("{distance}", "" + d);
        }
        return string;
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_NEAR_DESCRIPTION;
    }
}

