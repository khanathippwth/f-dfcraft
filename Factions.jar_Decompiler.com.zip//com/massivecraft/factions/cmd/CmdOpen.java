/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdOpen
extends FCommand {
    public CmdOpen() {
        this.aliases.add("open");
        this.optionalArgs.put("yes/no", "flip");
        this.requirements = new CommandRequirements.Builder(Permission.OPEN).playerOnly().noDisableOnLock().withRole(Role.MODERATOR).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostOpen(), TL.COMMAND_OPEN_TOOPEN, TL.COMMAND_OPEN_FOROPEN)) {
            return;
        }
        commandContext.faction.setOpen(commandContext.argAsBool(0, !commandContext.faction.getOpen()));
        String string = commandContext.faction.getOpen() ? TL.COMMAND_OPEN_OPEN.toString() : TL.COMMAND_OPEN_CLOSED.toString();
        for (FPlayer fPlayer : FPlayers.getInstance().getOnlinePlayers()) {
            if (fPlayer.getFactionIntId() == commandContext.faction.getIntId()) {
                fPlayer.msg(TL.COMMAND_OPEN_CHANGES, commandContext.fPlayer.getName(), string);
                continue;
            }
            fPlayer.msg(TL.COMMAND_OPEN_CHANGED, commandContext.faction.getTag(fPlayer.getFaction()), string);
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_OPEN_DESCRIPTION;
    }
}

