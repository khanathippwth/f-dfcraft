/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.Board;
import com.massivecraft.factions.FLocation;
import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.perms.PermissibleActions;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdOwner
extends FCommand {
    public CmdOwner() {
        this.aliases.add("owner");
        this.optionalArgs.put("player", "you");
        this.requirements = new CommandRequirements.Builder(Permission.OWNER).withAction(PermissibleActions.OWNER).playerOnly().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        FPlayer fPlayer;
        boolean bl = commandContext.fPlayer.isAdminBypassing();
        if (!bl && !commandContext.assertHasFaction()) {
            return;
        }
        if (!FactionsPlugin.getInstance().conf().factions().ownedArea().isEnabled()) {
            commandContext.msg(TL.COMMAND_OWNER_DISABLED, new Object[0]);
            return;
        }
        if (!bl && FactionsPlugin.getInstance().conf().factions().ownedArea().getLimitPerFaction() > 0 && commandContext.faction.getCountOfClaimsWithOwners() >= FactionsPlugin.getInstance().conf().factions().ownedArea().getLimitPerFaction()) {
            commandContext.msg(TL.COMMAND_OWNER_LIMIT, FactionsPlugin.getInstance().conf().factions().ownedArea().getLimitPerFaction());
            return;
        }
        FLocation fLocation = new FLocation(commandContext.fPlayer);
        Faction faction = Board.getInstance().getFactionAt(fLocation);
        if (faction != commandContext.faction) {
            if (!faction.isNormal()) {
                commandContext.msg(TL.COMMAND_OWNER_NOTCLAIMED, new Object[0]);
                return;
            }
            if (!bl) {
                commandContext.msg(TL.COMMAND_OWNER_WRONGFACTION, new Object[0]);
                return;
            }
        }
        if ((fPlayer = commandContext.argAsBestFPlayerMatch(0, commandContext.fPlayer)) == null) {
            return;
        }
        String string = fPlayer.getName();
        if (fPlayer.getFaction() != commandContext.faction) {
            commandContext.msg(TL.COMMAND_OWNER_NOTMEMBER, string);
            return;
        }
        if (commandContext.args.isEmpty() && commandContext.faction.doesLocationHaveOwnersSet(fLocation)) {
            commandContext.faction.clearClaimOwnership(fLocation);
            commandContext.msg(TL.COMMAND_OWNER_CLEARED, new Object[0]);
            return;
        }
        if (commandContext.faction.isPlayerInOwnerList(fPlayer, fLocation)) {
            commandContext.faction.removePlayerAsOwner(fPlayer, fLocation);
            commandContext.msg(TL.COMMAND_OWNER_REMOVED, string);
            return;
        }
        if (!commandContext.payForCommand(FactionsPlugin.getInstance().conf().economy().getCostOwner(), TL.COMMAND_OWNER_TOSET, TL.COMMAND_OWNER_FORSET)) {
            return;
        }
        commandContext.faction.setPlayerAsOwner(fPlayer, fLocation);
        commandContext.msg(TL.COMMAND_OWNER_ADDED, string);
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_OWNER_DESCRIPTION;
    }
}

