/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.Board;
import com.massivecraft.factions.FLocation;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdOwnerList
extends FCommand {
    public CmdOwnerList() {
        this.aliases.add("ownerlist");
        this.requirements = new CommandRequirements.Builder(Permission.OWNERLIST).playerOnly().noDisableOnLock().build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        String string;
        boolean bl = commandContext.fPlayer.isAdminBypassing();
        if (!bl && !commandContext.assertHasFaction()) {
            return;
        }
        if (!FactionsPlugin.getInstance().conf().factions().ownedArea().isEnabled()) {
            commandContext.msg(TL.COMMAND_OWNERLIST_DISABLED, new Object[0]);
            return;
        }
        FLocation fLocation = new FLocation(commandContext.fPlayer);
        Faction faction = commandContext.faction;
        if (Board.getInstance().getFactionAt(fLocation) != commandContext.faction) {
            if (!bl) {
                commandContext.msg(TL.COMMAND_OWNERLIST_WRONGFACTION, new Object[0]);
                return;
            }
            faction = Board.getInstance().getFactionAt(fLocation);
            if (!faction.isNormal()) {
                commandContext.msg(TL.COMMAND_OWNERLIST_NOTCLAIMED, new Object[0]);
                return;
            }
        }
        if ((string = faction.getOwnerListString(fLocation)) == null || string.isEmpty()) {
            commandContext.msg(TL.COMMAND_OWNERLIST_NONE, new Object[0]);
            return;
        }
        commandContext.msg(TL.COMMAND_OWNERLIST_OWNERS, string);
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_OWNERLIST_DESCRIPTION;
    }
}

