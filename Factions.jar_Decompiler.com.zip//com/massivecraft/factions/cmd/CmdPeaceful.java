/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;

public class CmdPeaceful
extends FCommand {
    public CmdPeaceful() {
        this.aliases.add("peaceful");
        this.requiredArgs.add("faction");
        this.requirements = new CommandRequirements.Builder(Permission.SET_PEACEFUL).build();
    }

    @Override
    public void perform(CommandContext commandContext) {
        String string;
        Faction faction = commandContext.argAsFaction(0);
        if (faction == null) {
            return;
        }
        if (faction.isPeaceful()) {
            string = TL.COMMAND_PEACEFUL_REVOKE.toString();
            faction.setPeaceful(false);
        } else {
            string = TL.COMMAND_PEACEFUL_GRANT.toString();
            faction.setPeaceful(true);
        }
        for (FPlayer fPlayer : FPlayers.getInstance().getOnlinePlayers()) {
            String string2;
            String string3 = string2 = commandContext.fPlayer == null ? TL.GENERIC_SERVERADMIN.toString() : commandContext.fPlayer.describeTo(fPlayer, true);
            if (fPlayer.getFaction() == faction) {
                fPlayer.msg(TL.COMMAND_PEACEFUL_YOURS, string2, string);
                continue;
            }
            fPlayer.msg(TL.COMMAND_PEACEFUL_OTHER, string2, string, faction.getTag(fPlayer));
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_PEACEFUL_DESCRIPTION;
    }
}

