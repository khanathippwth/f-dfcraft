/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 */
package com.massivecraft.factions.cmd;

import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.cmd.CommandContext;
import com.massivecraft.factions.cmd.CommandRequirements;
import com.massivecraft.factions.cmd.FCommand;
import com.massivecraft.factions.config.file.PermissionsConfig;
import com.massivecraft.factions.config.file.TranslationsConfig;
import com.massivecraft.factions.data.MemoryFaction;
import com.massivecraft.factions.perms.PermSelector;
import com.massivecraft.factions.perms.PermSelectorRegistry;
import com.massivecraft.factions.perms.PermissibleAction;
import com.massivecraft.factions.perms.PermissibleActionRegistry;
import com.massivecraft.factions.perms.Role;
import com.massivecraft.factions.perms.selector.UnknownSelector;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import moss.factions.shade.net.kyori.adventure.audience.Audience;
import moss.factions.shade.net.kyori.adventure.text.Component;
import moss.factions.shade.net.kyori.adventure.text.ComponentBuilder;
import moss.factions.shade.net.kyori.adventure.text.TextComponent;
import moss.factions.shade.net.kyori.adventure.text.minimessage.MiniMessage;
import moss.factions.shade.net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import moss.factions.shade.net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import moss.factions.shade.net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;

public class CmdPerm
extends FCommand {
    public CmdPerm() {
        this.aliases.addAll(FactionsPlugin.getInstance().tl().commands().permissions().getAliases());
        this.requirements = new CommandRequirements.Builder(Permission.PERMISSIONS).memberOnly().withRole(Role.ADMIN).build();
        this.addSubCommand(new CmdPermAdd());
        this.addSubCommand(new CmdPermList());
        this.addSubCommand(new CmdPermListOverride());
        this.addSubCommand(new CmdPermMove());
        this.addSubCommand(new CmdPermRemove());
        this.addSubCommand(new CmdPermShow());
        this.addSubCommand(new CmdPermShowOverride());
        this.addSubCommand(new CmdPermReset(this));
    }

    private static int length(ComponentBuilder<TextComponent, TextComponent.Builder> componentBuilder) {
        return ChatColor.stripColor((String)LegacyComponentSerializer.legacySection().serialize((Component)componentBuilder.build())).length();
    }

    @Override
    public void perform(CommandContext commandContext) {
        this.listSelectors(commandContext, FactionsPlugin.getInstance().getAdventure().player(commandContext.player), ((MemoryFaction)commandContext.faction).getPermissions(), FactionsPlugin.getInstance().tl().commands().permissions());
    }

    private void listSelectors(CommandContext commandContext, Audience audience, LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap, TranslationsConfig.Commands.Permissions permissions) {
        int n = 0;
        String string = "/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " " + (String)permissions.getAliases().getFirst() + " ";
        String string2 = (String)permissions.move().getAliases().getFirst() + " ";
        String string3 = (String)permissions.remove().getAliases().getFirst() + " ";
        String string4 = (String)permissions.show().getAliases().getFirst() + " ";
        if (!permissions.list().getHeader().isEmpty()) {
            audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.list().getHeader(), Placeholder.parsed("commandadd", string + (String)permissions.add().getAliases().getFirst()), Placeholder.parsed("commandoverride", string + (String)permissions.listOverride().getAliases().getFirst())));
        }
        for (Map.Entry<PermSelector, Map<String, Boolean>> entry : linkedHashMap.entrySet()) {
            audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.list().getItem(), Placeholder.component("name", entry.getKey().displayName()), Placeholder.component("value", entry.getKey().displayValue(commandContext.faction)), Placeholder.parsed("commandmoveup", string + string2 + ++n + " " + (String)permissions.move().getAliasUp().getFirst()), Placeholder.parsed("commandmovedown", string + string2 + n + " " + (String)permissions.move().getAliasDown().getFirst()), Placeholder.parsed("commandremove", string + string3 + entry.getKey().serialize()), Placeholder.parsed("commandshow", string + string4 + n), Placeholder.parsed("rownumber", Integer.toString(n))));
        }
        if (!permissions.list().getFooter().isEmpty()) {
            audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.list().getFooter(), Placeholder.parsed("commandadd", string + (String)permissions.add().getAliases().getFirst()), Placeholder.parsed("commandoverride", string + (String)permissions.listOverride().getAliases().getFirst())));
        }
    }

    private void listOverrideSelectors(CommandContext commandContext, Audience audience, TranslationsConfig.Commands.Permissions permissions) {
        PermissionsConfig permissionsConfig = FactionsPlugin.getInstance().getConfigManager().getPermissionsConfig();
        List<PermSelector> list = permissionsConfig.getOverridePermissionsOrder();
        Map<PermSelector, Map<String, Boolean>> map = permissionsConfig.getOverridePermissions();
        int n = 0;
        String string = "/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " " + (String)permissions.getAliases().getFirst() + " " + (String)permissions.showOverride().getAliases().getFirst() + " ";
        if (!permissions.listOverride().getHeader().isEmpty()) {
            audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.listOverride().getHeader()));
        }
        for (PermSelector permSelector : list) {
            HashSet<String> hashSet = new HashSet<String>(map.get(permSelector).keySet());
            permissionsConfig.getHiddenActions().forEach(hashSet::remove);
            if (hashSet.isEmpty()) continue;
            audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.listOverride().getItem(), Placeholder.component("name", permSelector.displayName()), Placeholder.component("value", permSelector.displayValue(commandContext.faction)), Placeholder.parsed("commandshow", string + ++n), Placeholder.unparsed("rownumber", Integer.toString(n))));
        }
        if (!permissions.listOverride().getFooter().isEmpty()) {
            audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.listOverride().getFooter()));
        }
    }

    private void showSelector(CommandContext commandContext, int n, PermSelector permSelector, Audience audience, LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap, TranslationsConfig.Commands.Permissions permissions) {
        int n2 = 0;
        String string = "/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " " + (String)permissions.getAliases().getFirst() + " ";
        boolean bl = true;
        for (Map.Entry<PermSelector, Map<String, Boolean>> entry : linkedHashMap.entrySet()) {
            if (++n2 != n && !entry.getKey().equals(permSelector)) continue;
            bl = false;
            if (!permissions.show().getHeader().isEmpty()) {
                audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.show().getHeader(), Placeholder.component("name", entry.getKey().displayName()), Placeholder.component("value", entry.getKey().displayValue(commandContext.faction)), Placeholder.unparsed("rownumber", Integer.toString(n2)), Placeholder.parsed("command", string + (String)permissions.add().getAliases().getFirst() + " " + entry.getKey().serialize())));
            }
            for (Map.Entry<String, Boolean> entry2 : entry.getValue().entrySet()) {
                if (FactionsPlugin.getInstance().getConfigManager().getPermissionsConfig().getHiddenActions().contains(entry2.getKey())) continue;
                PermissibleAction permissibleAction = PermissibleActionRegistry.get(entry2.getKey());
                audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.show().getItem(), Placeholder.unparsed("shortdesc", permissibleAction.getShortDescription()), Placeholder.unparsed("desc", permissibleAction.getDescription()), Placeholder.unparsed("state", entry2.getValue().toString()), Placeholder.parsed("commandremove", string + (String)permissions.remove().getAliases().getFirst() + " " + entry.getKey().serialize() + " " + permissibleAction.getName())));
            }
            if (permissions.show().getFooter().isEmpty()) continue;
            audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.show().getFooter(), Placeholder.component("name", entry.getKey().displayName()), Placeholder.component("value", entry.getKey().displayValue(commandContext.faction)), Placeholder.unparsed("rownumber", Integer.toString(n2)), Placeholder.parsed("command", string + (String)permissions.add().getAliases().getFirst() + " " + entry.getKey().serialize())));
        }
        if (bl) {
            audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.show().getSelectorNotFound()));
        }
    }

    private void showOverrideSelector(CommandContext commandContext, int n, PermSelector object, Audience audience, TranslationsConfig.Commands.Permissions permissions) {
        Object object2;
        PermissionsConfig permissionsConfig = FactionsPlugin.getInstance().getConfigManager().getPermissionsConfig();
        List<PermSelector> list = permissionsConfig.getOverridePermissionsOrder();
        Map<PermSelector, Map<String, Boolean>> map = permissionsConfig.getOverridePermissions();
        int n2 = 0;
        if (object == null && n >= 0) {
            for (PermSelector object3 : list) {
                object2 = new HashSet<String>(map.get(object3).keySet());
                permissionsConfig.getHiddenActions().forEach(arg_0 -> object2.remove(arg_0));
                if (object2.isEmpty() || ++n2 != n) continue;
                object = object3;
                break;
            }
        } else if (object != null) {
            if (list.contains(object)) {
                Iterator<Map.Entry<String, Boolean>> iterator = new HashSet<String>(map.get(object).keySet());
                permissionsConfig.getHiddenActions().forEach(arg_0 -> iterator.remove(arg_0));
                if (iterator.isEmpty()) {
                    object = null;
                }
            } else {
                object = null;
            }
        }
        if (object == null) {
            audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.showOverride().getSelectorNotFound()));
            return;
        }
        if (!permissions.showOverride().getHeader().isEmpty()) {
            audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.showOverride().getHeader(), Placeholder.component("name", object.displayName()), Placeholder.component("value", object.displayValue(commandContext.faction)), Placeholder.unparsed("rownumber", Integer.toString(n2))));
        }
        for (Map.Entry<String, Boolean> entry : map.get(object).entrySet()) {
            if (FactionsPlugin.getInstance().getConfigManager().getPermissionsConfig().getHiddenActions().contains(entry.getKey())) continue;
            object2 = PermissibleActionRegistry.get(entry.getKey());
            audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.showOverride().getItem(), Placeholder.unparsed("shortdesc", object2.getShortDescription()), Placeholder.unparsed("desc", object2.getDescription()), Placeholder.unparsed("state", entry.getValue().toString())));
        }
        if (!permissions.showOverride().getFooter().isEmpty()) {
            audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.showOverride().getFooter(), Placeholder.component("name", object.displayName()), Placeholder.component("value", object.displayValue(commandContext.faction)), Placeholder.unparsed("rownumber", Integer.toString(n2))));
        }
    }

    @Override
    public TL getUsageTranslation() {
        return TL.COMMAND_PERMS_DESCRIPTION;
    }

    class CmdPermAdd
    extends CmdPermAbstract {
        CmdPermAdd() {
            this.aliases.addAll(FactionsPlugin.getInstance().tl().commands().permissions().add().getAliases());
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        @Override
        void perform(CommandContext commandContext, Audience audience, LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap, TranslationsConfig.Commands.Permissions permissions) {
            if (commandContext.args.isEmpty()) {
                ArrayList<String> arrayList = new ArrayList<String>(PermSelectorRegistry.getSelectors());
                Collections.sort(arrayList);
                TextComponent.Builder builder = Component.text();
                builder.append((Component)MiniMessage.miniMessage().deserialize(permissions.add().getAvailableSelectorsIntro()));
                ChatColor.stripColor((String)LegacyComponentSerializer.legacySection().serialize((Component)builder.build()));
                int n = CmdPerm.length(builder);
                String string = "/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " " + (String)permissions.getAliases().getFirst() + " " + (String)permissions.add().getAliases().getFirst() + " ";
                for (String string3 : arrayList) {
                    builder.append(MiniMessage.miniMessage().deserialize(permissions.add().getAvailableSelectorsSelector(), Placeholder.parsed("command", string + string3), Placeholder.unparsed("selector", string3)));
                    n = CmdPerm.length(builder);
                    if (n < 50) continue;
                    n = 0;
                    audience.sendMessage(builder);
                    builder = Component.text();
                }
                if (n <= 0) return;
                audience.sendMessage(builder);
                return;
            }
            if (commandContext.args.size() == 1) {
                Object object;
                String string = commandContext.argAsString(0);
                PermSelector permSelector = null;
                String string4 = null;
                try {
                    permSelector = PermSelectorRegistry.createOrThrow(string);
                } catch (Exception exception) {
                    string4 = exception.getMessage();
                }
                if (permSelector == null) {
                    object = PermSelectorRegistry.getDescriptor(string);
                    if (object == null) {
                        if (string.contains(":")) {
                            audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.add().getSelectorCreateFail(), (TagResolver)Placeholder.unparsed("error", string4 == null ? "???" : string4)));
                            return;
                        } else {
                            audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.add().getSelectorNotFound()));
                        }
                        return;
                    }
                    if (object.acceptsEmpty()) {
                        permSelector = object.create("");
                    } else {
                        Map<String, String> map = object.getOptions(commandContext.faction);
                        if (object.getInstructions() != null) {
                            audience.sendMessage(Component.text(object.getInstructions()));
                            audience.sendMessage((Component)MiniMessage.miniMessage().deserialize("/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " " + (String)permissions.getAliases().getFirst() + " " + (String)permissions.add().getAliases().getFirst() + " " + object.getName() + ":" + permissions.add().getSelectorOptionHere()));
                        }
                        if (map == null) return;
                        TextComponent.Builder builder = Component.text();
                        builder.append((Component)MiniMessage.miniMessage().deserialize(permissions.add().getSelectorOptionsIntro()));
                        int n = CmdPerm.length(builder);
                        String string5 = "/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " " + (String)permissions.getAliases().getFirst() + " " + (String)permissions.add().getAliases().getFirst() + " ";
                        for (Map.Entry<String, String> entry : map.entrySet()) {
                            builder.append(MiniMessage.miniMessage().deserialize(permissions.add().getSelectorOptionsItem(), Placeholder.parsed("command", string5 + entry.getKey()), Placeholder.unparsed("display", entry.getValue())));
                            n = CmdPerm.length(builder);
                            if (n < 50) continue;
                            n = 0;
                            audience.sendMessage(builder);
                            builder = Component.text();
                        }
                        if (n <= 0) return;
                        audience.sendMessage(builder);
                        return;
                    }
                }
                if (linkedHashMap.containsKey(permSelector)) {
                    object = PermissibleActionRegistry.getActions().stream().map(PermissibleAction::getName).collect(Collectors.toCollection(ArrayList::new));
                    object.removeAll(FactionsPlugin.getInstance().getConfigManager().getPermissionsConfig().getHiddenActions());
                    object.removeAll(linkedHashMap.get(permSelector).keySet());
                    Collections.sort(object);
                    TextComponent.Builder builder = Component.text();
                    builder.append((Component)MiniMessage.miniMessage().deserialize(permissions.add().getActionOptionsIntro()));
                    int n = CmdPerm.length(builder);
                    String string6 = "/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " " + (String)permissions.getAliases().getFirst() + " " + (String)permissions.add().getAliases().getFirst() + " " + permSelector.serialize() + " ";
                    Iterator iterator = object.iterator();
                    while (iterator.hasNext()) {
                        String string7 = (String)iterator.next();
                        builder.append(MiniMessage.miniMessage().deserialize(permissions.add().getActionOptionsItem(), Placeholder.unparsed("description", PermissibleActionRegistry.get(string7).getDescription()), Placeholder.unparsed("action", string7), Placeholder.parsed("commandtrue", string6 + string7 + " " + (String)permissions.add().getActionAllowAlias().getFirst()), Placeholder.parsed("commandfalse", string6 + string7 + " " + (String)permissions.add().getActionDenyAlias().getFirst())));
                        n = CmdPerm.length(builder);
                        if (n < 50) continue;
                        n = 0;
                        audience.sendMessage(builder);
                        builder = Component.text();
                    }
                    if (n <= 0) return;
                    audience.sendMessage(builder);
                    return;
                } else {
                    linkedHashMap.put(permSelector, new LinkedHashMap());
                    CmdPerm.this.listSelectors(commandContext, audience, linkedHashMap, permissions);
                }
                return;
            }
            if (commandContext.args.size() == 2) {
                audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.add().getActionAllowDenyOptions(), Placeholder.unparsed("allow", (String)permissions.add().getActionAllowAlias().getFirst()), Placeholder.unparsed("deny", (String)permissions.add().getActionDenyAlias().getFirst())));
                return;
            } else {
                if (commandContext.args.size() != 3) return;
                PermSelector permSelector = PermSelectorRegistry.create(commandContext.argAsString(0), false);
                if (permSelector instanceof UnknownSelector) {
                    audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.add().getSelectorNotFound()));
                    return;
                } else if (!linkedHashMap.containsKey(permSelector)) {
                    audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.add().getSelectorNotFound()));
                    return;
                } else {
                    PermissibleAction permissibleAction = PermissibleActionRegistry.get(commandContext.argAsString(1));
                    if (permissibleAction == null || FactionsPlugin.getInstance().getConfigManager().getPermissionsConfig().getHiddenActions().contains(permissibleAction.getName())) {
                        audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.add().getActionNotFound()));
                        return;
                    } else {
                        Boolean bl = null;
                        String string = commandContext.argAsString(2);
                        if (permissions.add().getActionAllowAlias().stream().anyMatch(string2 -> string2.equalsIgnoreCase(string))) {
                            bl = true;
                        } else if (permissions.add().getActionDenyAlias().stream().anyMatch(string2 -> string2.equalsIgnoreCase(string))) {
                            bl = false;
                        }
                        if (bl == null) {
                            audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.add().getActionAllowDenyOptions(), Placeholder.unparsed("allow", (String)permissions.add().getActionAllowAlias().getFirst()), Placeholder.unparsed("deny", (String)permissions.add().getActionDenyAlias().getFirst())));
                            return;
                        }
                        linkedHashMap.get(permSelector).put(permissibleAction.getName(), bl);
                        CmdPerm.this.showSelector(commandContext, -1, permSelector, audience, linkedHashMap, permissions);
                    }
                }
            }
        }
    }

    class CmdPermList
    extends CmdPermAbstract {
        CmdPermList() {
            this.aliases.addAll(FactionsPlugin.getInstance().tl().commands().permissions().list().getAliases());
        }

        @Override
        void perform(CommandContext commandContext, Audience audience, LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap, TranslationsConfig.Commands.Permissions permissions) {
            CmdPerm.this.listSelectors(commandContext, audience, linkedHashMap, permissions);
        }
    }

    class CmdPermListOverride
    extends CmdPermAbstract {
        CmdPermListOverride() {
            this.aliases.addAll(FactionsPlugin.getInstance().tl().commands().permissions().listOverride().getAliases());
        }

        @Override
        void perform(CommandContext commandContext, Audience audience, LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap, TranslationsConfig.Commands.Permissions permissions) {
            CmdPerm.this.listOverrideSelectors(commandContext, audience, permissions);
        }
    }

    class CmdPermMove
    extends CmdPermAbstract {
        CmdPermMove() {
            this.aliases.addAll(FactionsPlugin.getInstance().tl().commands().permissions().move().getAliases());
        }

        @Override
        void perform(CommandContext commandContext, Audience audience, LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap, TranslationsConfig.Commands.Permissions permissions) {
            int n;
            if (commandContext.args.size() < 2) {
                return;
            }
            int n2 = commandContext.argAsInt(0, -1);
            if (n2 < 1) {
                return;
            }
            String string = commandContext.argAsString(1);
            if (permissions.move().getAliasUp().stream().anyMatch(string2 -> string2.equalsIgnoreCase(string))) {
                n = n2 - 1;
            } else if (permissions.move().getAliasDown().stream().anyMatch(string2 -> string2.equalsIgnoreCase(string))) {
                n = n2;
            } else {
                audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.move().getErrorOptions(), Placeholder.unparsed("up", (String)permissions.move().getAliasUp().getFirst()), Placeholder.unparsed("down", (String)permissions.move().getAliasDown().getFirst())));
                return;
            }
            if (n < 1) {
                audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.move().getErrorHighest()));
            } else if (n > linkedHashMap.size() - 1) {
                audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.move().getErrorLowest()));
            } else {
                LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap2 = new LinkedHashMap<PermSelector, Map<String, Boolean>>();
                int n3 = 0;
                Map.Entry<PermSelector, Map<String, Boolean>> entry = null;
                for (Map.Entry<PermSelector, Map<String, Boolean>> entry2 : linkedHashMap.entrySet()) {
                    if (++n3 == n) {
                        entry = entry2;
                        continue;
                    }
                    linkedHashMap2.put(entry2.getKey(), entry2.getValue());
                    if (entry == null) continue;
                    linkedHashMap2.put(entry.getKey(), entry.getValue());
                    entry = null;
                }
                ((MemoryFaction)commandContext.faction).setPermissions(linkedHashMap2);
                linkedHashMap = linkedHashMap2;
            }
            CmdPerm.this.listSelectors(commandContext, audience, linkedHashMap, permissions);
        }
    }

    class CmdPermRemove
    extends CmdPermAbstract {
        CmdPermRemove() {
            this.aliases.addAll(FactionsPlugin.getInstance().tl().commands().permissions().remove().getAliases());
        }

        @Override
        void perform(CommandContext commandContext, Audience audience, LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap, TranslationsConfig.Commands.Permissions permissions) {
            if (commandContext.args.isEmpty()) {
                CmdPerm.this.listSelectors(commandContext, audience, linkedHashMap, permissions);
            } else if (commandContext.args.size() == 1) {
                PermSelector permSelector = PermSelectorRegistry.create(commandContext.argAsString(0), false);
                linkedHashMap.remove(permSelector);
                CmdPerm.this.listSelectors(commandContext, audience, linkedHashMap, permissions);
            } else {
                PermSelector permSelector = PermSelectorRegistry.create(commandContext.argAsString(0), false);
                Map<String, Boolean> map = linkedHashMap.get(permSelector);
                if (map != null) {
                    String string = commandContext.argAsString(1);
                    map.keySet().removeIf(string2 -> string2.equalsIgnoreCase(string));
                }
                CmdPerm.this.showSelector(commandContext, -1, permSelector, audience, linkedHashMap, permissions);
            }
        }
    }

    class CmdPermShow
    extends CmdPermAbstract {
        CmdPermShow() {
            this.aliases.addAll(FactionsPlugin.getInstance().tl().commands().permissions().show().getAliases());
            this.optionalArgs.put("selector", null);
        }

        @Override
        void perform(CommandContext commandContext, Audience audience, LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap, TranslationsConfig.Commands.Permissions permissions) {
            if (commandContext.args.isEmpty()) {
                CmdPerm.this.listSelectors(commandContext, audience, linkedHashMap, permissions);
                return;
            }
            int n = commandContext.argAsInt(0, -1);
            PermSelector permSelector = null;
            if (n < 1) {
                permSelector = PermSelectorRegistry.create(commandContext.argAsString(0), false);
            }
            CmdPerm.this.showSelector(commandContext, n, permSelector, audience, linkedHashMap, permissions);
        }
    }

    class CmdPermShowOverride
    extends CmdPermAbstract {
        CmdPermShowOverride() {
            this.aliases.addAll(FactionsPlugin.getInstance().tl().commands().permissions().showOverride().getAliases());
            this.optionalArgs.put("selector", null);
        }

        @Override
        void perform(CommandContext commandContext, Audience audience, LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap, TranslationsConfig.Commands.Permissions permissions) {
            if (commandContext.args.isEmpty()) {
                CmdPerm.this.listOverrideSelectors(commandContext, audience, permissions);
                return;
            }
            int n = commandContext.argAsInt(0, -1);
            PermSelector permSelector = null;
            if (n < 1) {
                permSelector = PermSelectorRegistry.create(commandContext.argAsString(0), false);
            }
            CmdPerm.this.showOverrideSelector(commandContext, n, permSelector, audience, permissions);
        }
    }

    class CmdPermReset
    extends CmdPermAbstract {
        CmdPermReset(CmdPerm cmdPerm) {
            this.aliases.addAll(FactionsPlugin.getInstance().tl().commands().permissions().reset().getAliases());
        }

        @Override
        void perform(CommandContext commandContext, Audience audience, LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap, TranslationsConfig.Commands.Permissions permissions) {
            if (commandContext.args.size() == 1 && commandContext.argAsString(0, "").equals(permissions.reset().getConfirmWord())) {
                ((MemoryFaction)commandContext.faction).resetPerms();
                audience.sendMessage((Component)MiniMessage.miniMessage().deserialize(permissions.reset().getResetComplete()));
            } else {
                String string = "/" + (String)FactionsPlugin.getInstance().conf().getCommandBase().getFirst() + " " + (String)permissions.getAliases().getFirst() + " " + (String)permissions.reset().getAliases().getFirst() + " " + permissions.reset().getConfirmWord();
                audience.sendMessage(MiniMessage.miniMessage().deserialize(permissions.reset().getWarning(), (TagResolver)Placeholder.parsed("command", string)));
            }
        }
    }

    static abstract class CmdPermAbstract
    extends FCommand {
        CmdPermAbstract() {
            this.requirements = new CommandRequirements.Builder(Permission.PERMISSIONS).memberOnly().withRole(Role.ADMIN).noErrorOnManyArgs().build();
        }

        @Override
        public void perform(CommandContext commandContext) {
            Audience audience = FactionsPlugin.getInstance().getAdventure().player(commandContext.player);
            LinkedHashMap<PermSelector, Map<String, Boolean>> linkedHashMap = ((MemoryFaction)commandContext.faction).getPermissions();
            this.perform(commandContext, audience, linkedHashMap, FactionsPlugin.getInstance().tl().commands().permissions());
        }

        abstract void perform(CommandContext var1, Audience var2, LinkedHashMap<PermSelector, Map<String, Boolean>> var3, TranslationsConfig.Commands.Permissions var4);
    }
}

