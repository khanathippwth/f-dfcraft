/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 */
package com.massivecraft.factions.util;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.Faction;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.iface.RelationParticipator;
import com.massivecraft.factions.perms.Relation;
import com.massivecraft.factions.util.TL;
import com.massivecraft.factions.util.TextUtil;
import moss.factions.shade.net.kyori.adventure.text.format.TextColor;
import org.bukkit.ChatColor;

public class RelationUtil {
    public static String describeThatToMe(RelationParticipator relationParticipator, RelationParticipator relationParticipator2, boolean bl) {
        String string = "";
        Faction faction = RelationUtil.getFaction(relationParticipator);
        if (faction == null) {
            return "ERROR";
        }
        Faction faction2 = RelationUtil.getFaction(relationParticipator2);
        if (relationParticipator instanceof Faction) {
            string = relationParticipator2 instanceof FPlayer && faction2 == faction ? TL.GENERIC_YOURFACTION.toString() : faction.getTag();
        } else if (relationParticipator instanceof FPlayer) {
            FPlayer fPlayer = (FPlayer)relationParticipator;
            string = relationParticipator == relationParticipator2 ? TL.GENERIC_YOU.toString() : (faction == faction2 ? fPlayer.getNameAndTitle() : fPlayer.getNameAndTag());
        }
        if (bl) {
            string = TextUtil.upperCaseFirst(string);
        }
        return RelationUtil.getColorStringOfThatToMe(relationParticipator, relationParticipator2) + string;
    }

    public static String describeThatToMe(RelationParticipator relationParticipator, RelationParticipator relationParticipator2) {
        return RelationUtil.describeThatToMe(relationParticipator, relationParticipator2, false);
    }

    public static Relation getRelationTo(RelationParticipator relationParticipator, RelationParticipator relationParticipator2) {
        return RelationUtil.getRelationTo(relationParticipator2, relationParticipator, false);
    }

    public static Relation getRelationTo(RelationParticipator relationParticipator, RelationParticipator relationParticipator2, boolean bl) {
        Faction faction = RelationUtil.getFaction(relationParticipator2);
        if (faction == null) {
            return Relation.NEUTRAL;
        }
        Faction faction2 = RelationUtil.getFaction(relationParticipator);
        if (faction2 == null) {
            return Relation.NEUTRAL;
        }
        if (!faction.isNormal() || !faction2.isNormal()) {
            return Relation.NEUTRAL;
        }
        if (faction.equals(faction2)) {
            return Relation.MEMBER;
        }
        if (!bl && (faction2.isPeaceful() || faction.isPeaceful())) {
            return Relation.NEUTRAL;
        }
        if (faction2.getRelationWish((Faction)faction).value >= faction.getRelationWish((Faction)faction2).value) {
            return faction.getRelationWish(faction2);
        }
        return faction2.getRelationWish(faction);
    }

    public static Faction getFaction(RelationParticipator relationParticipator) {
        if (relationParticipator instanceof Faction) {
            return (Faction)relationParticipator;
        }
        if (relationParticipator instanceof FPlayer) {
            return ((FPlayer)relationParticipator).getFaction();
        }
        return null;
    }

    @Deprecated
    public static ChatColor getColorOfThatToMe(RelationParticipator relationParticipator, RelationParticipator relationParticipator2) {
        return TextUtil.getClosest(RelationUtil.getTextColorOfThatToMe(relationParticipator, relationParticipator2));
    }

    public static String getColorStringOfThatToMe(RelationParticipator relationParticipator, RelationParticipator relationParticipator2) {
        return TextUtil.getString(RelationUtil.getTextColorOfThatToMe(relationParticipator, relationParticipator2));
    }

    public static TextColor getTextColorOfThatToMe(RelationParticipator relationParticipator, RelationParticipator relationParticipator2) {
        Faction faction = RelationUtil.getFaction(relationParticipator);
        if (faction != null) {
            if (faction.isPeaceful() && faction != RelationUtil.getFaction(relationParticipator2)) {
                return FactionsPlugin.getInstance().conf().colors().relations().getPeaceful();
            }
            if (faction.isSafeZone() && faction != RelationUtil.getFaction(relationParticipator2)) {
                return FactionsPlugin.getInstance().conf().colors().factions().getSafezone();
            }
            if (faction.isWarZone() && faction != RelationUtil.getFaction(relationParticipator2)) {
                return FactionsPlugin.getInstance().conf().colors().factions().getWarzone();
            }
        }
        return RelationUtil.getRelationTo(relationParticipator, relationParticipator2).getTextColor();
    }
}

