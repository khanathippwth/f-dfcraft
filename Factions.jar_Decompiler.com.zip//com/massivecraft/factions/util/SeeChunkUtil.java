/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.scheduler.BukkitRunnable
 */
package com.massivecraft.factions.util;

import com.massivecraft.factions.Board;
import com.massivecraft.factions.FLocation;
import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.util.VisualizeUtil;
import com.massivecraft.factions.util.material.MaterialDb;
import com.massivecraft.factions.util.particle.ParticleColor;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class SeeChunkUtil
extends BukkitRunnable {
    private final Set<UUID> playersSeeingChunks = new HashSet<UUID>();
    private final boolean useColor;
    private final Particle effect;

    public SeeChunkUtil() {
        String string = FactionsPlugin.getInstance().conf().commands().seeChunk().getParticleName();
        this.effect = FactionsPlugin.getInstance().getParticleProvider().effectFromString(string);
        this.useColor = FactionsPlugin.getInstance().conf().commands().seeChunk().isRelationalColor();
        FactionsPlugin.getInstance().getLogger().info(FactionsPlugin.getInstance().txt().parse("Using %s as the ParticleEffect for /f sc", FactionsPlugin.getInstance().getParticleProvider().effectName(this.effect)));
    }

    public void run() {
        for (UUID uUID : this.playersSeeingChunks) {
            Player player = Bukkit.getPlayer((UUID)uUID);
            if (player == null) {
                this.playersSeeingChunks.remove(uUID);
                continue;
            }
            if (!FactionsPlugin.getInstance().worldUtil().isEnabled((CommandSender)player)) continue;
            FPlayer fPlayer = FPlayers.getInstance().getByPlayer(player);
            SeeChunkUtil.showPillars(player, fPlayer, this.effect, this.useColor);
        }
    }

    public void updatePlayerInfo(UUID uUID, boolean bl) {
        if (bl) {
            this.playersSeeingChunks.add(uUID);
        } else {
            this.playersSeeingChunks.remove(uUID);
        }
    }

    public static void showPillars(Player player, FPlayer fPlayer, Particle particle, boolean bl) {
        World world = player.getWorld();
        FLocation fLocation = new FLocation(player);
        int n = (int)fLocation.getX();
        int n2 = (int)fLocation.getZ();
        ParticleColor particleColor = null;
        if (bl) {
            ChatColor chatColor = Board.getInstance().getFactionAt(fLocation).getRelationTo(fPlayer).getColor();
            particleColor = ParticleColor.fromChatColor(chatColor);
        }
        int n3 = n * 16;
        int n4 = n2 * 16;
        SeeChunkUtil.showPillar(player, world, n3, n4, particle, particleColor);
        n3 = n * 16 + 16;
        n4 = n2 * 16;
        SeeChunkUtil.showPillar(player, world, n3, n4, particle, particleColor);
        n3 = n * 16;
        n4 = n2 * 16 + 16;
        SeeChunkUtil.showPillar(player, world, n3, n4, particle, particleColor);
        n3 = n * 16 + 16;
        n4 = n2 * 16 + 16;
        SeeChunkUtil.showPillar(player, world, n3, n4, particle, particleColor);
    }

    public static void showPillar(Player player, World world, int n, int n2, Particle particle, ParticleColor particleColor) {
        for (int i = player.getLocation().getBlockY() - 30; i < player.getLocation().getBlockY() + 30; ++i) {
            Location location = new Location(world, (double)n, (double)i, (double)n2);
            if (location.getBlock().getType() != Material.AIR) continue;
            if (particle != null) {
                if (particleColor == null) {
                    FactionsPlugin.getInstance().getParticleProvider().playerSpawn(player, particle, location, 1);
                    continue;
                }
                FactionsPlugin.getInstance().getParticleProvider().playerSpawn(player, particle, location, particleColor);
                continue;
            }
            Material material = i % 5 == 0 ? MaterialDb.get("REDSTONE_LAMP") : MaterialDb.get("GLASS_PANE");
            VisualizeUtil.addLocation(player, location, material);
        }
    }
}

