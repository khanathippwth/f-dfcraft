/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Effect
 *  org.bukkit.Location
 */
package com.massivecraft.factions.util;

import java.util.Collection;
import java.util.Random;
import org.bukkit.Effect;
import org.bukkit.Location;

public class SmokeUtil {
    public static final Random random = new Random();

    public static void spawnSingle(Location location, int n) {
        if (location == null) {
            return;
        }
        location.getWorld().playEffect(location.clone(), Effect.SMOKE, n);
    }

    public static void spawnSingle(Location location) {
        SmokeUtil.spawnSingle(location, 4);
    }

    public static void spawnSingleRandom(Location location) {
        SmokeUtil.spawnSingle(location, random.nextInt(9));
    }

    public static void spawnCloudSimple(Location location) {
        for (int i = 0; i <= 8; ++i) {
            SmokeUtil.spawnSingle(location, i);
        }
    }

    public static void spawnCloudSimple(Collection<Location> collection) {
        for (Location location : collection) {
            SmokeUtil.spawnCloudSimple(location);
        }
    }

    public static void spawnCloudRandom(Location location, float f) {
        int n = (int)Math.floor(f * 9.0f);
        for (int i = 0; i < n; ++i) {
            SmokeUtil.spawnSingleRandom(location.clone());
        }
    }

    public static void spawnCloudRandom(Collection<Location> collection, float f) {
        for (Location location : collection) {
            SmokeUtil.spawnCloudRandom(location, f);
        }
    }
}

