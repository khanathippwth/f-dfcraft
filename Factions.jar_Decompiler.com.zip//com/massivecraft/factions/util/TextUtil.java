/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 */
package com.massivecraft.factions.util;

import com.massivecraft.factions.util.Mini;
import com.massivecraft.factions.util.TL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import moss.factions.shade.net.kyori.adventure.text.Component;
import moss.factions.shade.net.kyori.adventure.text.format.NamedTextColor;
import moss.factions.shade.net.kyori.adventure.text.format.TextColor;
import moss.factions.shade.net.kyori.adventure.text.minimessage.MiniMessage;
import moss.factions.shade.net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;
import org.bukkit.Material;

public class TextUtil {
    public final Map<String, String> tags;
    private static boolean noHex = true;
    public static final transient Pattern patternTag = Pattern.compile("<([a-zA-Z0-9_]*)>");
    private static final String titleizeLine = TextUtil.repeat("_", 52);
    private static final int titleizeBalance = -1;

    public TextUtil(boolean bl) {
        noHex = bl;
        this.tags = new HashMap<String, String>();
    }

    public static String getString(TextColor textColor) {
        if (noHex || textColor instanceof NamedTextColor) {
            return TextUtil.getClosest(textColor).toString();
        }
        String string = String.format("%06x", textColor.value());
        StringBuilder stringBuilder = new StringBuilder("\u00a7x");
        for (int i = 0; i < string.length(); ++i) {
            stringBuilder.append('\u00a7').append(string.charAt(i));
        }
        return stringBuilder.toString();
    }

    public static ChatColor getClosest(TextColor textColor) {
        NamedTextColor namedTextColor = textColor instanceof NamedTextColor ? (NamedTextColor)textColor : NamedTextColor.nearestTo(textColor);
        return switch (namedTextColor.toString()) {
            case "black" -> ChatColor.BLACK;
            case "dark_blue" -> ChatColor.DARK_BLUE;
            case "dark_green" -> ChatColor.DARK_GREEN;
            case "dark_aqua" -> ChatColor.DARK_AQUA;
            case "dark_red" -> ChatColor.DARK_RED;
            case "dark_purple" -> ChatColor.DARK_PURPLE;
            case "gold" -> ChatColor.GOLD;
            case "gray" -> ChatColor.GRAY;
            case "dark_gray" -> ChatColor.DARK_GRAY;
            case "blue" -> ChatColor.BLUE;
            case "green" -> ChatColor.GREEN;
            case "aqua" -> ChatColor.AQUA;
            case "red" -> ChatColor.RED;
            case "light_purple" -> ChatColor.LIGHT_PURPLE;
            case "yellow" -> ChatColor.YELLOW;
            default -> ChatColor.WHITE;
        };
    }

    public String parse(String string, Object ... objectArray) {
        return String.format(this.parse(string), objectArray);
    }

    public String parse(String string) {
        return this.parseTags(TextUtil.parseColor(string));
    }

    public String parseTags(String string) {
        return TextUtil.replaceTags(string, this.tags);
    }

    public static String replaceTags(String string, Map<String, String> map) {
        StringBuilder stringBuilder = new StringBuilder();
        Matcher matcher = patternTag.matcher(string);
        while (matcher.find()) {
            String string2 = matcher.group(1);
            String string3 = map.get(string2);
            if (string3 == null) {
                matcher.appendReplacement(stringBuilder, "<" + string2 + ">");
                continue;
            }
            matcher.appendReplacement(stringBuilder, string3);
        }
        matcher.appendTail(stringBuilder);
        return stringBuilder.toString();
    }

    public static String parseColor(String string) {
        string = TextUtil.parseColorAmp(string);
        string = TextUtil.parseColorAcc(string);
        string = TextUtil.parseColorTags(string);
        return ChatColor.translateAlternateColorCodes((char)'&', (String)string);
    }

    public static String parseColorAmp(String string) {
        string = string.replaceAll("(\u00a7([a-z0-9]))", "\u00a7$2");
        string = string.replaceAll("(&([a-z0-9]))", "\u00a7$2");
        string = string.replace("&&", "&");
        return string;
    }

    public static String parseColorAcc(String string) {
        return string.replace("`e", "").replace("`r", ChatColor.RED.toString()).replace("`R", ChatColor.DARK_RED.toString()).replace("`y", ChatColor.YELLOW.toString()).replace("`Y", ChatColor.GOLD.toString()).replace("`g", ChatColor.GREEN.toString()).replace("`G", ChatColor.DARK_GREEN.toString()).replace("`a", ChatColor.AQUA.toString()).replace("`A", ChatColor.DARK_AQUA.toString()).replace("`b", ChatColor.BLUE.toString()).replace("`B", ChatColor.DARK_BLUE.toString()).replace("`p", ChatColor.LIGHT_PURPLE.toString()).replace("`P", ChatColor.DARK_PURPLE.toString()).replace("`k", ChatColor.BLACK.toString()).replace("`s", ChatColor.GRAY.toString()).replace("`S", ChatColor.DARK_GRAY.toString()).replace("`w", ChatColor.WHITE.toString());
    }

    public static String parseColorTags(String string) {
        return string.replace("<empty>", "").replace("<black>", "\u00a70").replace("<navy>", "\u00a71").replace("<green>", "\u00a72").replace("<teal>", "\u00a73").replace("<red>", "\u00a74").replace("<purple>", "\u00a75").replace("<gold>", "\u00a76").replace("<silver>", "\u00a77").replace("<gray>", "\u00a78").replace("<blue>", "\u00a79").replace("<lime>", "\u00a7a").replace("<aqua>", "\u00a7b").replace("<rose>", "\u00a7c").replace("<pink>", "\u00a7d").replace("<yellow>", "\u00a7e").replace("<white>", "\u00a7f");
    }

    public static String upperCaseFirst(String string) {
        return string.substring(0, 1).toUpperCase() + string.substring(1);
    }

    public static String implode(List<String> list, String string) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < list.size(); ++i) {
            if (i != 0) {
                stringBuilder.append(string);
            }
            stringBuilder.append(list.get(i));
        }
        return stringBuilder.toString();
    }

    public static String repeat(String string, int n) {
        if (n <= 0) {
            return "";
        }
        return string + TextUtil.repeat(string, n - 1);
    }

    public static String getMaterialName(Material material) {
        return material.toString().replace('_', ' ').toLowerCase();
    }

    public String titleize(String string) {
        String string2 = ".[ " + this.parseTags("<l>") + string + this.parseTags("<a>") + " ].";
        int n = ChatColor.stripColor((String)string2).length();
        int n2 = titleizeLine.length() / 2;
        int n3 = n / 2 - -1;
        int n4 = n - n3 + -1;
        if (n3 < n2) {
            return this.parseTags("<a>") + titleizeLine.substring(0, n2 - n3) + string2 + titleizeLine.substring(n2 + n4);
        }
        return this.parseTags("<a>") + string2;
    }

    public static Component titleizeC(String string) {
        String string2 = (String)MiniMessage.miniMessage().serialize(LegacyComponentSerializer.legacySection().deserialize(string));
        String string3 = ".[ <dark_green>" + string2 + "<gold> ].";
        int n = ChatColor.stripColor((String)LegacyComponentSerializer.legacySection().serialize(Mini.parse(string3))).length();
        int n2 = titleizeLine.length() / 2;
        int n3 = n / 2 - -1;
        int n4 = n - n3 + -1;
        if (n3 < n2) {
            return Mini.parse("<gold>" + titleizeLine.substring(0, n2 - n3) + string3 + titleizeLine.substring(n2 + n4));
        }
        return Mini.parse("<gold>" + string3);
    }

    public ArrayList<String> getPage(List<String> list, int n, String string) {
        ArrayList<String> arrayList = new ArrayList<String>();
        int n2 = n - 1;
        int n3 = 9;
        int n4 = list.size() / n3 + 1;
        arrayList.add(this.titleize(string + " " + n + "/" + n4));
        if (n4 == 0) {
            arrayList.add(this.parseTags(TL.NOPAGES.toString()));
            return arrayList;
        }
        if (n2 < 0 || n > n4) {
            arrayList.add(this.parseTags(TL.INVALIDPAGE.format(n4)));
            return arrayList;
        }
        int n5 = n2 * n3;
        int n6 = n5 + n3;
        if (n6 > list.size()) {
            n6 = list.size();
        }
        arrayList.addAll(list.subList(n5, n6));
        return arrayList;
    }
}

