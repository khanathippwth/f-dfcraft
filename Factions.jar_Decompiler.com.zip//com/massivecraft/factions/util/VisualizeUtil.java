/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 */
package com.massivecraft.factions.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class VisualizeUtil {
    protected static final Map<UUID, Set<Location>> playerLocations = new HashMap<UUID, Set<Location>>();

    public static Set<Location> getPlayerLocations(Player player) {
        return VisualizeUtil.getPlayerLocations(player.getUniqueId());
    }

    public static Set<Location> getPlayerLocations(UUID uUID2) {
        return playerLocations.computeIfAbsent(uUID2, uUID -> new HashSet());
    }

    public static void addLocation(Player player, Location location, Material material) {
        VisualizeUtil.getPlayerLocations(player).add(location);
        player.sendBlockChange(location, material, (byte)0);
    }

    public static void addLocations(Player player, Map<Location, Material> map) {
        Set<Location> set = VisualizeUtil.getPlayerLocations(player);
        for (Map.Entry<Location, Material> entry : map.entrySet()) {
            set.add(entry.getKey());
            player.sendBlockChange(entry.getKey(), entry.getValue(), (byte)0);
        }
    }

    public static void addLocations(Player player, Collection<Location> collection, Material material) {
        Set<Location> set = VisualizeUtil.getPlayerLocations(player);
        for (Location location : collection) {
            set.add(location);
            player.sendBlockChange(location, material, (byte)0);
        }
    }

    public static void addBlocks(Player player, Collection<Block> collection, Material material) {
        Set<Location> set = VisualizeUtil.getPlayerLocations(player);
        for (Block block : collection) {
            Location location = block.getLocation();
            set.add(location);
            player.sendBlockChange(location, material, (byte)0);
        }
    }

    public static void clear(Player player) {
        Set<Location> set = VisualizeUtil.getPlayerLocations(player);
        if (set == null) {
            return;
        }
        for (Location location : set) {
            Block block = location.getWorld().getBlockAt(location);
            player.sendBlockChange(location, block.getType(), block.getData());
        }
        set.clear();
    }
}

