/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package com.massivecraft.factions.util;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FactionsPlugin;
import com.massivecraft.factions.struct.Permission;
import com.massivecraft.factions.util.TL;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public class WarmUpUtil {
    public static void process(final FPlayer fPlayer, Warmup warmup, TL tL, String string, final Runnable runnable, long l) {
        Player player = fPlayer.getPlayer();
        if (player != null && Permission.WARMUP_EXEMPT.has((CommandSender)player)) {
            l = 0L;
        }
        if (l > 0L) {
            if (fPlayer.isWarmingUp()) {
                fPlayer.msg(TL.WARMUPS_ALREADY, new Object[0]);
            } else {
                fPlayer.msg(tL.format(string, l), new Object[0]);
                int n = new BukkitRunnable(){

                    public void run() {
                        fPlayer.stopWarmup();
                        runnable.run();
                    }
                }.runTaskLater((Plugin)FactionsPlugin.getInstance(), l * 20L).getTaskId();
                fPlayer.addWarmup(warmup, n);
            }
        } else {
            runnable.run();
        }
    }

    public static enum Warmup {
        HOME,
        WARP,
        FLIGHT;

    }
}

