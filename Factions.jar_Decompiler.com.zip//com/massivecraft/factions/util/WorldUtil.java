/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package com.massivecraft.factions.util;

import com.massivecraft.factions.FactionsPlugin;
import java.util.HashSet;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class WorldUtil {
    private HashSet<String> worlds;
    private final boolean check;
    private boolean whitelist;

    public WorldUtil(FactionsPlugin factionsPlugin) {
        this.check = factionsPlugin.conf().restrictWorlds().isRestrictWorlds();
        if (!this.check) {
            return;
        }
        this.worlds = new HashSet<String>(factionsPlugin.conf().restrictWorlds().getWorldList());
        this.whitelist = factionsPlugin.conf().restrictWorlds().isWhitelist();
    }

    private boolean isEnabled(String string) {
        if (!this.check) {
            return true;
        }
        return this.whitelist == this.worlds.contains(string);
    }

    public boolean isEnabled(World world) {
        return this.isEnabled(world.getName());
    }

    public boolean isEnabled(CommandSender commandSender) {
        if (commandSender instanceof Player) {
            Player player = (Player)commandSender;
            return this.isEnabled(player.getWorld().getName());
        }
        return true;
    }
}

