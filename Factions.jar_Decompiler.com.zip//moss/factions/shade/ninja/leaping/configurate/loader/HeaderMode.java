/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package moss.factions.shade.ninja.leaping.configurate.loader;

public enum HeaderMode {
    PRESERVE,
    PRESET,
    NONE;

}

